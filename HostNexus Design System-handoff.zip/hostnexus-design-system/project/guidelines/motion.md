# HostNexus — Motion & interaction spec

Tokens: `--ease-out cubic-bezier(.22,1,.36,1)` (default for everything), `--ease-in-out` (loops only). Durations: `--dur-fast 160ms` (hover colour, press), `--dur-base 260ms` (chips, accordion, text fill), `--dur-slow 600ms` (image zoom), `--dur-reveal 900ms` (section entrances).
Rule of thumb: slow, soft, no bounces or springs. Always respect `prefers-reduced-motion`: show the end state, turn off parallax and marquees.

Observed in the source video = **[seen]**. Filled in to match = **[inferred]**.

## Global
- **Section reveal [seen]:** as each section's content enters the viewport (15% visible) it goes blur 12px → 0, opacity 0 → 1 and translateY 24px → 0 over 900ms. It plays once and doesn't reverse. Implemented as `Container` in `ui_kits/website/Shared.jsx`.
- **Stagger [inferred]:** child groups stagger 80–120ms (for example the heading, then the body, then the CTA).
- **Scroll:** native smooth scroll. Nothing scroll-jacks, and nothing is sticky. The nav scrolls away with the hero.

## Hero
- **Photo on load [inferred]:** the background photo eases from scale 1.08 → 1 over 1600ms.
- **Photo on scroll [inferred]:** parallax, translateY = scroll × 0.25.
- **Ghost wordmark [seen, parallax inferred]:** drifts down at scroll × 0.45 and fades out by 500px of scroll.
- **Headline [seen]:** blur-in reveal, 200ms after load.
- **Search pill:** focus uses `--ring-focus`. Submit smooth-scrolls to the listings.

## Our Story
- **Two-tone ink fill [seen]:** the lead statement's words go ink-400 → ink-900 in order, driven by scroll progress through the section (starting at 90% of the viewport height, finishing 60% of the viewport height later). Each word has a 260ms colour transition.

## Buttons & icon buttons
- **Hover:** background moves one step darker in 160ms.
- **Arrow chip [inferred]:** rotates 45° (↗ → →) over 260ms.
- **Press:** scale .97.
- **Disabled:** opacity .45, no motion.

## Cards (destination / listing)
- **Hover:** the image scales to 1.04 over 600ms inside a clipped frame. Text and scrim stay put.
- **Bento grid [seen]:** reveals as one block.

## Carousels (listings, testimonials)
- **Listings:** the arrows smooth-scroll the rail by one card width.
- **End state:** at either end the matching arrow is disabled.
- **Testimonial change [inferred]:** the new quote remounts with a 260ms cross-fade. Prev/next is manual; there's no autoplay.

## Partner strip & photo rail
- **Logo marquee [seen]:** `LogoStrip` scrolls continuously leftward, 40s per loop, linear, with the edges faded by a mask.
- **Photo rail [seen]:** the photos sit at staggered vertical offsets. Sideways drift is optional: a slow marquee, or parallax at scroll × 0.1 [inferred].
- **Hover [inferred]:** hovering pauses the marquee.

## FAQ accordion
- **Single open:** only one item is open at a time.
- **Height:** animates with a grid-template-rows 0fr → 1fr transition over 260ms.
- **Chevron:** swaps down ↔ up.
- **Question:** the open question's colour and weight change (ink, weight 500).

## Newsletter
- **Submit:** the card content swaps to a confirmation message with a 260ms fade.

## Footer
- **Headline and CTA [seen]:** blur-in reveal.
- **Giant wordmark [inferred]:** rises translateY 40px → 0 with the reveal. It stays solid, with no parallax.
