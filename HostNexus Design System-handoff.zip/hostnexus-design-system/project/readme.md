# HostNexus Design System

HostNexus is a hotel & stay-booking brand: a consumer marketing site that lets travelers search, compare and book hotels, resorts and cabins ("Find Your Perfect Stay at the Best Price"). The system is calm, photographic and premium — big quiet type, dusk architecture photography, one ember-orange accent.

## Sources
- `uploads/From Klickpin.com- Clear peaceful debate ideas… -pin-id-21462535722991179.mp4` — 26s screen-recording (720×1000) of a hotel-booking landing page concept branded **"StayGo"**. Every token, component and section here was extracted from frames of that video. No codebase, Figma or font files were provided.
- The video brand name "StayGo" has been replaced with **HostNexus** throughout.
- Per instruction, **no imagery from the video was saved**. All photos are placeholders (`<image-slot>` in the UI kit, `Media` placeholder in components) awaiting HostNexus-supplied images.

## Index
- `styles.css` — entry; imports `tokens/*.css` (fonts, colors, typography, spacing, effects, base)
- `guidelines/` — foundation specimen cards (Colors, Type, Spacing, Brand) + `motion.md` (per-section transitions & scroll effects)
- `components/` — React primitives (see list below), one `*.card.html` per folder
- `ui_kits/website/` — full landing-page recreation (`index.html`, section JSX, `data.js`, README)
- `thumbnail.html` — project tile · `SKILL.md` — Agent Skill wrapper
- `assets/` — not yet created: **no logo, partner logos or photography supplied**

## Components
- core: **Icon**, **Media**
- actions: **Button**, **IconButton**
- forms: **SearchBar**, **EmailField**
- cards: **DestinationCard**, **ListingCard**, **NewsletterCard**
- content: **Eyebrow**, **SectionHeader**, **Rating**, **Location**, **Accordion**, **Testimonial**, **LogoStrip**
- navigation: **NavBar**, **CarouselControls**

Intentional additions: **Icon** (inline Lucide paths so components don't depend on a CDN script) and **Media** (image frame with placeholder, since imagery is supplied separately).

## Content fundamentals
- **Voice:** warm, reassuring, benefit-led travel copy. Speaks to the reader as **you**, the company as **we** ("we connect you with hotels that fit your lifestyle").
- **Casing:** Headlines in **Title Case** ("Find Your Perfect Stay at the Best Price", "Got Questions? We're Here to Help."). Eyebrows, body, buttons in sentence/title case — never ALL CAPS.
- **Headlines** are short, two lines, often a promise or a question + answer. Exclamation marks allowed sparingly in taglines/quotes ("Trusted Stays, Seamless Booking Explore Now!").
- **Body** is one or two soft sentences, uses em dashes ("just a tap—effortless booking, ultimate comfort").
- **CTAs** are 2-word verbs: Sign In, Search, Learn More, Explore Now, Get Started, Plan Your Stay.
- **Proof** is stated plainly with bold numerals: "Trusted by over **10 million travelers**… average **rating of 4.8★**". Ratings read "(4.9 out of 5)".
- **Emoji:** none. The ★ glyph appears inline in copy only.
- **Vibe:** peaceful, confident, aspirational-but-accessible.

## Visual foundations
- **Color:** near-monochrome cool neutrals (ink #131519 → #FAFAFA) with a single accent, **Ember #EB8322**, used only for CTAs, arrow chips, active carousel dot. Dark sections use ink-950 #0B0D11 over photography. Night blues (#0C1A26–#2A5575) come from the hero photo, not UI chrome.
- **Type:** one neo-grotesk family (substituted with Inter Tight). Headlines weight 400 (not bold) with tight negative tracking (-0.025 to -0.035em). Brand name appears as a **giant wordmark**: ghosted at ~22% white behind the hero, and solid white edge-to-edge in the footer. Body text is small (14–16px) and grey; hierarchy comes from size, not weight.
- **Two-tone statements:** lead paragraphs start ink and fade to grey; on scroll words fill from grey to ink.
- **Spacing:** 4px base; generous — ~112px section padding, 64px gutters, 1280 container. Layouts are asymmetric two-column (small eyebrow + stat left, big statement right) or centered.
- **Backgrounds:** sections alternate white / #F4F4F5 / #FAFAFA. Hero and footer are full-bleed photographs. No gradients as decoration, no patterns or textures.
- **Imagery:** cinematic dusk/blue-hour architecture with warm interior light, misty forests, still water, tropical infinity pools. Cool teal/green shadows, amber highlights, slight desaturation.
- **Protection:** text over photos always gets a bottom-weighted dark scrim (`--overlay-photo`) — never a flat tint or capsule.
- **Corner radii:** media 14–20px; dark newsletter card 20px; **every control is a pill** (999px); icon buttons are circles.
- **Cards:** photo cards are borderless, shadowless, rounded 20px with scrim + white text; listing cards are just an image + text row; the newsletter card is solid ink with a large soft shadow.
- **Borders:** 1px hairlines (#ECECEE) for FAQ dividers; 1px #8E919A for outline buttons; translucent white (22%) for nav rule and glass search.
- **Shadows:** almost none. Only floating elements (newsletter card) lift with `--shadow-lg`.
- **Transparency & blur:** glass (dark 55% + 14px backdrop blur) for the hero search pill and arrow buttons over photos.
- **Motion:** slow, eased (cubic-bezier(.22,1,.36,1)). Sections blur-in (blur 12px → 0 + fade, ~900ms). Partner logos and photo rail drift as marquees. Image hover = 4% zoom over 600ms.
- **Hover:** fills darken one step (ember-500 → 600); outline buttons get a muted fill; the arrow chip rotates 45°. **Press:** scale .97.
- **Layout rules:** nav is transparent over the hero, not sticky in the source. Section headers put the action button bottom-right of the title.

## Iconography
- Thin (≈1.5px) rounded line icons: arrow-up-right (in every CTA chip), chevrons (carousel, accordion), map-pin, star (filled amber), shield-check. Style matches **Lucide** — no icon files were supplied, so Lucide path data is embedded in the `Icon` component (**substitution — flag**). CDN: `https://unpkg.com/lucide@0.460.0`.
- Quotation marks in testimonials are a large typographic “ glyph in ink-300, not an icon.
- No emoji. No icon font. No PNG icons.
- **Logo:** none provided. The brand name is set in type (Inter Tight 500, -0.04em) wherever a mark would go. Partner logos (the video shows luxury hotel chains) are **not** reproduced — `LogoStrip` renders placeholder names until real files are supplied.

## Fonts
Source typeface unknown (neo-grotesk, Neue Haas / Inter Display-like). **Substituted with Inter Tight (Google Fonts)** via `tokens/fonts.css`. Provide licensed font files to replace it.
