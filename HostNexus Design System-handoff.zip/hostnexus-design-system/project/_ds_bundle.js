/* @ds-bundle: {"format":4,"namespace":"HostNexusDesignSystem_229e3d","components":[{"name":"Button","sourcePath":"components/actions/Button.jsx"},{"name":"IconButton","sourcePath":"components/actions/IconButton.jsx"},{"name":"DestinationCard","sourcePath":"components/cards/DestinationCard.jsx"},{"name":"ListingCard","sourcePath":"components/cards/ListingCard.jsx"},{"name":"NewsletterCard","sourcePath":"components/cards/NewsletterCard.jsx"},{"name":"Accordion","sourcePath":"components/content/Accordion.jsx"},{"name":"Eyebrow","sourcePath":"components/content/Eyebrow.jsx"},{"name":"Location","sourcePath":"components/content/Location.jsx"},{"name":"LogoStrip","sourcePath":"components/content/LogoStrip.jsx"},{"name":"Rating","sourcePath":"components/content/Rating.jsx"},{"name":"SectionHeader","sourcePath":"components/content/SectionHeader.jsx"},{"name":"Testimonial","sourcePath":"components/content/Testimonial.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"Media","sourcePath":"components/core/Media.jsx"},{"name":"EmailField","sourcePath":"components/forms/EmailField.jsx"},{"name":"SearchBar","sourcePath":"components/forms/SearchBar.jsx"},{"name":"CarouselControls","sourcePath":"components/navigation/CarouselControls.jsx"},{"name":"NavBar","sourcePath":"components/navigation/NavBar.jsx"}],"sourceHashes":{"components/actions/Button.jsx":"2a1b407b231d","components/actions/IconButton.jsx":"68b6c6409680","components/cards/DestinationCard.jsx":"72c7c48cf83b","components/cards/ListingCard.jsx":"d6c6d57a2fdf","components/cards/NewsletterCard.jsx":"e401318db3a3","components/content/Accordion.jsx":"5fe52e5c5c4d","components/content/Eyebrow.jsx":"eafed2b0db06","components/content/Location.jsx":"9d80c64493d7","components/content/LogoStrip.jsx":"ed05c0585548","components/content/Rating.jsx":"98cdf4b92f87","components/content/SectionHeader.jsx":"6e8befc60b96","components/content/Testimonial.jsx":"10b16c85b472","components/core/Icon.jsx":"7d06182d1fe3","components/core/Media.jsx":"7e59a315802f","components/forms/EmailField.jsx":"ea75516df8f0","components/forms/SearchBar.jsx":"3c6f10e9c6d7","components/navigation/CarouselControls.jsx":"6c58410f31fc","components/navigation/NavBar.jsx":"ce8ac2f49c28","ui_kits/website/Community.jsx":"fd7f108d619c","ui_kits/website/Destinations.jsx":"b672d4b2c67b","ui_kits/website/Faq.jsx":"b82e50d8d920","ui_kits/website/Footer.jsx":"9278cc619428","ui_kits/website/Hero.jsx":"0418d307ddc0","ui_kits/website/Listings.jsx":"e1431711bb71","ui_kits/website/Shared.jsx":"82cdf36f9d00","ui_kits/website/Story.jsx":"b1886346ae76","ui_kits/website/Testimonials.jsx":"10a16873222b","ui_kits/website/data.js":"13da3eeab389","ui_kits/website/image-slot.js":"fff26d081c8d"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.HostNexusDesignSystem_229e3d = window.HostNexusDesignSystem_229e3d || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/content/Eyebrow.jsx
try { (() => {
function Eyebrow({
  children,
  tone = 'dark',
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      font: '500 var(--text-sm)/1.2 var(--font-sans)',
      color: tone === 'light' ? 'var(--text-inverse-muted)' : 'var(--text-body)',
      letterSpacing: '-0.005em',
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Eyebrow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Eyebrow.jsx", error: String((e && e.message) || e) }); }

// components/content/LogoStrip.jsx
try { (() => {
function LogoStrip({
  logos = [],
  marquee = true,
  height = 36,
  style
}) {
  const row = logos.map((l, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      flexShrink: 0,
      height,
      display: 'flex',
      alignItems: 'center',
      opacity: .6,
      filter: 'grayscale(1)'
    }
  }, l.src ? /*#__PURE__*/React.createElement("img", {
    src: l.src,
    alt: l.name,
    style: {
      height: '100%',
      width: 'auto'
    }
  }) : /*#__PURE__*/React.createElement("span", {
    style: {
      font: '400 20px var(--font-sans)',
      letterSpacing: '0.04em',
      color: 'var(--ink-600)',
      whiteSpace: 'nowrap'
    }
  }, l.name)));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      overflow: 'hidden',
      maskImage: 'linear-gradient(90deg,transparent,#000 10%,#000 90%,transparent)',
      WebkitMaskImage: 'linear-gradient(90deg,transparent,#000 10%,#000 90%,transparent)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("style", null, '@keyframes hnMarquee{from{transform:translateX(0)}to{transform:translateX(-50%)}}'), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 64,
      width: 'max-content',
      animation: marquee ? 'hnMarquee 40s linear infinite' : 'none'
    }
  }, row, marquee && row));
}
Object.assign(__ds_scope, { LogoStrip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/LogoStrip.jsx", error: String((e && e.message) || e) }); }

// components/content/SectionHeader.jsx
try { (() => {
function SectionHeader({
  eyebrow,
  title,
  description,
  action,
  align = 'left',
  tone = 'dark',
  style
}) {
  const c = align === 'center';
  const fg = tone === 'light' ? 'var(--text-inverse)' : 'var(--text-strong)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: c ? 'column' : 'row',
      alignItems: c ? 'center' : 'flex-end',
      justifyContent: 'space-between',
      gap: c ? 16 : 32,
      textAlign: c ? 'center' : 'left',
      width: '100%',
      boxSizing: 'border-box',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16,
      alignItems: c ? 'center' : 'flex-start',
      maxWidth: c ? 720 : 640,
      width: c ? '100%' : undefined,
      flex: c ? undefined : '1 1 auto',
      minWidth: 0
    }
  }, eyebrow && /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, {
    tone: tone
  }, eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      font: '400 var(--text-h2)/1.1 var(--font-sans)',
      letterSpacing: 'var(--tracking-heading)',
      color: fg,
      textWrap: 'balance'
    }
  }, title), description && c && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      font: '400 var(--text-sm)/1.5 var(--font-sans)',
      color: tone === 'light' ? 'var(--text-inverse-muted)' : 'var(--text-body)'
    }
  }, description)), description && !c && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      maxWidth: 340,
      font: '400 var(--text-sm)/1.5 var(--font-sans)',
      color: 'var(--text-body)'
    }
  }, description), action && /*#__PURE__*/React.createElement("div", {
    style: {
      flexShrink: 0
    }
  }, action));
}
Object.assign(__ds_scope, { SectionHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/SectionHeader.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
// Path data copied from Lucide (ISC). Stroke 1.5 matches source.
const P = {
  'arrow-up-right': ['M7 7h10v10', 'M7 17 17 7'],
  'arrow-right': ['M5 12h14', 'm12 5 7 7-7 7'],
  'chevron-left': ['m15 18-6-6 6-6'],
  'chevron-right': ['m9 18 6-6-6-6'],
  'chevron-down': ['m6 9 6 6 6-6'],
  'chevron-up': ['m18 15-6-6-6 6'],
  'map-pin': ['M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0', {
    c: [12, 10, 3]
  }],
  'star': ['M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z'],
  'search': [{
    c: [11, 11, 8]
  }, 'm21 21-4.3-4.3'],
  'shield-check': ['M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z', 'm9 12 2 2 4-4'],
  'menu': ['M4 12h16', 'M4 6h16', 'M4 18h16'],
  'x': ['M18 6 6 18', 'm6 6 12 12'],
  'mail': [{
    r: [2, 4, 20, 16, 2]
  }, 'm22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7']
};
function Icon({
  name,
  size = 18,
  strokeWidth = 1.5,
  color = 'currentColor',
  fill = 'none',
  style
}) {
  const d = P[name] || [];
  return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: fill,
    stroke: color,
    strokeWidth: strokeWidth,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      flexShrink: 0,
      display: 'block',
      ...style
    },
    "aria-hidden": "true"
  }, d.map((p, i) => typeof p === 'string' ? /*#__PURE__*/React.createElement("path", {
    key: i,
    d: p
  }) : p.c ? /*#__PURE__*/React.createElement("circle", {
    key: i,
    cx: p.c[0],
    cy: p.c[1],
    r: p.c[2]
  }) : /*#__PURE__*/React.createElement("rect", {
    key: i,
    x: p.r[0],
    y: p.r[1],
    width: p.r[2],
    height: p.r[3],
    rx: p.r[4]
  })));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/actions/Button.jsx
try { (() => {
const SZ = {
  sm: {
    h: 36,
    px: 16,
    fs: 13,
    chip: 26
  },
  md: {
    h: 44,
    px: 20,
    fs: 14,
    chip: 32
  },
  lg: {
    h: 52,
    px: 28,
    fs: 15,
    chip: 38
  }
};
const V = {
  primary: {
    bg: 'var(--accent)',
    fg: 'var(--on-accent)',
    bd: 'transparent',
    chipBg: 'var(--white)',
    chipFg: 'var(--ink-900)',
    hover: 'var(--accent-hover)'
  },
  outline: {
    bg: 'transparent',
    fg: 'var(--text-strong)',
    bd: 'var(--border-strong)',
    chipBg: 'var(--accent)',
    chipFg: 'var(--white)',
    hover: 'var(--surface-muted)'
  },
  dark: {
    bg: 'var(--ink-900)',
    fg: 'var(--white)',
    bd: 'transparent',
    chipBg: 'var(--accent)',
    chipFg: 'var(--white)',
    hover: 'var(--ink-700)'
  },
  light: {
    bg: 'var(--white)',
    fg: 'var(--ink-900)',
    bd: 'transparent',
    chipBg: 'var(--accent)',
    chipFg: 'var(--white)',
    hover: 'var(--ink-50)'
  },
  ghost: {
    bg: 'transparent',
    fg: 'currentColor',
    bd: 'transparent',
    chipBg: 'var(--accent)',
    chipFg: 'var(--white)',
    hover: 'rgba(127,127,127,.12)'
  }
};
function Button({
  children,
  variant = 'primary',
  size = 'md',
  arrow = false,
  disabled = false,
  fullWidth = false,
  onClick,
  type = 'button',
  style
}) {
  const s = SZ[size] || SZ.md,
    v = V[variant] || V.primary;
  const [h, setH] = React.useState(false),
    [p, setP] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", {
    type: type,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setH(true),
    onMouseLeave: () => {
      setH(false);
      setP(false);
    },
    onMouseDown: () => setP(true),
    onMouseUp: () => setP(false),
    style: {
      display: fullWidth ? 'flex' : 'inline-flex',
      width: fullWidth ? '100%' : undefined,
      alignItems: 'center',
      justifyContent: 'center',
      gap: 12,
      height: s.h,
      padding: arrow ? `0 ${(s.h - s.chip) / 2}px 0 ${s.px}px` : `0 ${s.px}px`,
      borderRadius: 'var(--radius-pill)',
      border: `1px solid ${v.bd}`,
      background: h && !disabled ? v.hover : v.bg,
      color: v.fg,
      font: `500 ${s.fs}px/1 var(--font-sans)`,
      letterSpacing: '-0.01em',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? .45 : 1,
      transform: p && !disabled ? 'scale(.97)' : 'none',
      transition: 'background var(--dur-fast) var(--ease-out),transform var(--dur-fast) var(--ease-out)',
      whiteSpace: 'nowrap',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", null, children), arrow && /*#__PURE__*/React.createElement("span", {
    style: {
      width: s.chip,
      height: s.chip,
      borderRadius: '50%',
      background: v.chipBg,
      color: v.chipFg,
      display: 'grid',
      placeItems: 'center',
      boxShadow: variant === 'primary' ? 'inset 0 0 0 1px var(--ember-600)' : 'none',
      transform: h && !disabled ? 'rotate(45deg)' : 'none',
      transition: 'transform var(--dur-base) var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "arrow-up-right",
    size: Math.round(s.chip * 0.5)
  })));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/Button.jsx", error: String((e && e.message) || e) }); }

// components/actions/IconButton.jsx
try { (() => {
const V = {
  accent: ['var(--accent)', 'var(--white)', 'transparent'],
  outline: ['transparent', 'var(--text-strong)', 'var(--border-default)'],
  light: ['var(--white)', 'var(--ink-900)', 'transparent'],
  dark: ['var(--ink-900)', 'var(--white)', 'transparent'],
  glass: ['rgba(255,255,255,.18)', 'var(--white)', 'rgba(255,255,255,.28)']
};
function IconButton({
  icon = 'arrow-up-right',
  variant = 'accent',
  size = 40,
  label,
  disabled = false,
  onClick,
  style
}) {
  const [bg, fg, bd] = V[variant] || V.accent;
  const [h, setH] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", {
    "aria-label": label || icon,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      width: size,
      height: size,
      borderRadius: '50%',
      border: `1px solid ${bd}`,
      background: bg,
      color: fg,
      display: 'grid',
      placeItems: 'center',
      padding: 0,
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? .4 : 1,
      backdropFilter: variant === 'glass' ? 'var(--blur-glass)' : undefined,
      filter: h && !disabled ? 'brightness(.93)' : 'none',
      transition: 'filter var(--dur-fast)',
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: Math.round(size * 0.42)
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/content/Accordion.jsx
try { (() => {
function Accordion({
  items = [],
  defaultOpen = 0,
  style
}) {
  const [open, setOpen] = React.useState(defaultOpen);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      ...style
    }
  }, items.map((it, i) => {
    const o = open === i;
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        borderBottom: '1px solid var(--border-subtle)'
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: () => setOpen(o ? -1 : i),
      style: {
        width: '100%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: 16,
        padding: '20px 8px',
        background: 'none',
        border: 0,
        cursor: 'pointer',
        textAlign: 'left',
        font: `${o ? 500 : 400} 15px/1.3 var(--font-sans)`,
        color: o ? 'var(--text-strong)' : 'var(--text-body)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, it.q), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: o ? 'chevron-up' : 'chevron-down',
      size: 16
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateRows: o ? '1fr' : '0fr',
        transition: 'grid-template-rows var(--dur-base) var(--ease-out)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        overflow: 'hidden'
      }
    }, /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        padding: '0 40px 20px 8px',
        font: '400 13px/1.55 var(--font-sans)',
        color: 'var(--text-muted)'
      }
    }, it.a))));
  }));
}
Object.assign(__ds_scope, { Accordion });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Accordion.jsx", error: String((e && e.message) || e) }); }

// components/content/Location.jsx
try { (() => {
function Location({
  children,
  tone = 'dark',
  size = 12
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 4,
      whiteSpace: 'nowrap',
      font: `400 ${size}px var(--font-sans)`,
      color: tone === 'light' ? 'var(--text-inverse-muted)' : 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "map-pin",
    size: size + 1
  }), children);
}
Object.assign(__ds_scope, { Location });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Location.jsx", error: String((e && e.message) || e) }); }

// components/content/Rating.jsx
try { (() => {
function Rating({
  value = 4.9,
  max = 5,
  tone = 'dark',
  size = 12
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      whiteSpace: 'nowrap',
      font: `400 ${size}px var(--font-sans)`,
      color: tone === 'light' ? 'var(--text-inverse-muted)' : 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "star",
    size: size + 1,
    fill: "var(--star)",
    color: "var(--star)",
    strokeWidth: 1
  }), "(", value, " out of ", max, ")");
}
Object.assign(__ds_scope, { Rating });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Rating.jsx", error: String((e && e.message) || e) }); }

// components/content/Testimonial.jsx
try { (() => {
function Testimonial({
  headline,
  body,
  author,
  avatar,
  rating = 5,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'auto 1fr',
      gap: 32,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      font: '500 120px/0.8 var(--font-sans)',
      color: 'var(--ink-300)',
      height: 70,
      letterSpacing: '-0.05em'
    }
  }, "\u201C"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      font: '400 var(--text-h3)/1.12 var(--font-sans)',
      letterSpacing: 'var(--tracking-heading)',
      color: 'var(--text-strong)',
      textWrap: 'balance'
    }
  }, headline), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      font: '400 14px/1.6 var(--font-sans)',
      color: 'var(--text-body)',
      maxWidth: 520
    }
  }, body), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 36,
      height: 36,
      borderRadius: '50%',
      overflow: 'hidden',
      background: 'var(--ink-200)',
      flexShrink: 0
    }
  }, avatar && (typeof avatar === 'string' ? /*#__PURE__*/React.createElement("img", {
    src: avatar,
    alt: "",
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }) : avatar)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: '500 14px var(--font-sans)',
      color: 'var(--text-strong)',
      whiteSpace: 'nowrap'
    }
  }, author), /*#__PURE__*/React.createElement(__ds_scope.Rating, {
    value: rating,
    size: 11
  })))));
}
Object.assign(__ds_scope, { Testimonial });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Testimonial.jsx", error: String((e && e.message) || e) }); }

// components/core/Media.jsx
try { (() => {
function Media({
  src,
  alt = '',
  children,
  radius = 'var(--radius-lg)',
  height = '100%',
  label,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      overflow: 'hidden',
      borderRadius: radius,
      height,
      background: 'var(--ink-100)',
      ...style
    }
  }, src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: alt,
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }) : children ? children : /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'grid',
      placeItems: 'center',
      font: '500 11px var(--font-sans)',
      color: 'var(--ink-400)',
      letterSpacing: '.02em'
    }
  }, label || 'Image'));
}
Object.assign(__ds_scope, { Media });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Media.jsx", error: String((e && e.message) || e) }); }

// components/cards/DestinationCard.jsx
try { (() => {
function DestinationCard({
  title,
  location,
  rating,
  image,
  media,
  height = 300,
  size = 'md',
  onClick,
  style
}) {
  const [h, setH] = React.useState(false);
  const lg = size === 'lg';
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClick,
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      position: 'relative',
      height,
      borderRadius: 'var(--radius-lg)',
      overflow: 'hidden',
      cursor: onClick ? 'pointer' : 'default',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      transform: h ? 'scale(1.04)' : 'scale(1)',
      transition: 'transform var(--dur-slow) var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Media, {
    src: image,
    radius: 0,
    label: title
  }, media)), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'var(--overlay-photo)',
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: lg ? 24 : 18,
      right: lg ? 24 : 18,
      bottom: lg ? 22 : 16,
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: `400 ${lg ? 28 : 20}px/1.1 var(--font-sans)`,
      letterSpacing: 'var(--tracking-heading)',
      color: 'var(--white)'
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      flexWrap: 'wrap'
    }
  }, location && /*#__PURE__*/React.createElement(__ds_scope.Location, {
    tone: "light"
  }, location), rating != null && /*#__PURE__*/React.createElement(__ds_scope.Rating, {
    value: rating,
    tone: "light"
  }))), /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "arrow-up-right",
    variant: "glass",
    size: lg ? 36 : 30,
    label: "Open"
  })));
}
Object.assign(__ds_scope, { DestinationCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/DestinationCard.jsx", error: String((e && e.message) || e) }); }

// components/cards/ListingCard.jsx
try { (() => {
function ListingCard({
  title,
  price,
  location,
  image,
  media,
  imageHeight = 220,
  width,
  onClick,
  style
}) {
  const [h, setH] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClick,
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12,
      width,
      cursor: onClick ? 'pointer' : 'default',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: 'var(--radius-md)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      transform: h ? 'scale(1.04)' : 'none',
      transition: 'transform var(--dur-slow) var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Media, {
    src: image,
    height: imageHeight,
    radius: 0,
    label: title
  }, media))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'baseline',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: '400 15px var(--font-sans)',
      color: 'var(--text-strong)'
    }
  }, title), price && /*#__PURE__*/React.createElement("span", {
    style: {
      font: '500 17px var(--font-sans)',
      color: 'var(--text-strong)',
      letterSpacing: '-0.01em'
    }
  }, price)), location && /*#__PURE__*/React.createElement(__ds_scope.Location, null, location)));
}
Object.assign(__ds_scope, { ListingCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/ListingCard.jsx", error: String((e && e.message) || e) }); }

// components/forms/EmailField.jsx
try { (() => {
function EmailField({
  placeholder = 'you@email.com',
  defaultValue = '',
  tone = 'dark',
  onSubmit,
  style
}) {
  const [v, setV] = React.useState(defaultValue);
  const dark = tone === 'dark';
  return /*#__PURE__*/React.createElement("form", {
    onSubmit: e => {
      e.preventDefault();
      onSubmit && onSubmit(v);
    },
    style: {
      display: 'flex',
      alignItems: 'center',
      height: 48,
      padding: 4,
      paddingLeft: 18,
      boxSizing: 'border-box',
      borderRadius: 'var(--radius-pill)',
      background: dark ? 'var(--ink-700)' : 'var(--white)',
      border: `1px solid ${dark ? 'rgba(255,255,255,.14)' : 'var(--border-default)'}`,
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", {
    type: "email",
    value: v,
    placeholder: placeholder,
    onChange: e => setV(e.target.value),
    style: {
      flex: 1,
      minWidth: 0,
      border: 0,
      outline: 0,
      background: 'transparent',
      font: '400 14px var(--font-sans)',
      color: dark ? 'var(--white)' : 'var(--text-strong)'
    }
  }), /*#__PURE__*/React.createElement("button", {
    type: "submit",
    "aria-label": "Subscribe",
    style: {
      width: 40,
      height: 40,
      borderRadius: '50%',
      border: 0,
      background: dark ? 'var(--white)' : 'var(--accent)',
      color: dark ? 'var(--ink-900)' : 'var(--white)',
      display: 'grid',
      placeItems: 'center',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "arrow-up-right",
    size: 18
  })));
}
Object.assign(__ds_scope, { EmailField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/EmailField.jsx", error: String((e && e.message) || e) }); }

// components/cards/NewsletterCard.jsx
try { (() => {
function NewsletterCard({
  message = 'Join our community of travelers and experience unforgettable stays.',
  placeholder = 'support@hostnexus.com',
  onSubmit,
  width = 300,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width,
      maxWidth: '100%',
      boxSizing: 'border-box',
      background: 'var(--surface-card-dark)',
      borderRadius: 'var(--radius-lg)',
      padding: '28px 20px 20px',
      display: 'flex',
      flexDirection: 'column',
      gap: 28,
      boxShadow: 'var(--shadow-lg)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      textAlign: 'center',
      font: '400 16px/1.5 var(--font-sans)',
      color: 'var(--white)',
      textWrap: 'balance'
    }
  }, message), /*#__PURE__*/React.createElement(__ds_scope.EmailField, {
    placeholder: placeholder,
    onSubmit: onSubmit
  }));
}
Object.assign(__ds_scope, { NewsletterCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/NewsletterCard.jsx", error: String((e && e.message) || e) }); }

// components/forms/SearchBar.jsx
try { (() => {
function SearchBar({
  placeholder = 'Search hotel',
  buttonLabel = 'Search',
  tone = 'glass',
  value,
  onChange,
  onSubmit,
  width = 300,
  style
}) {
  const [v, setV] = React.useState(value ?? '');
  const glass = tone === 'glass';
  return /*#__PURE__*/React.createElement("form", {
    onSubmit: e => {
      e.preventDefault();
      onSubmit && onSubmit(v);
    },
    style: {
      display: 'flex',
      alignItems: 'center',
      width,
      maxWidth: '100%',
      height: 44,
      padding: 4,
      paddingLeft: 18,
      boxSizing: 'border-box',
      borderRadius: 'var(--radius-pill)',
      background: glass ? 'var(--glass-dark)' : 'var(--white)',
      border: `1px solid ${glass ? 'var(--border-inverse)' : 'var(--border-default)'}`,
      backdropFilter: glass ? 'var(--blur-glass)' : undefined,
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", {
    value: v,
    placeholder: placeholder,
    onChange: e => {
      setV(e.target.value);
      onChange && onChange(e.target.value);
    },
    style: {
      flex: 1,
      minWidth: 0,
      border: 0,
      outline: 0,
      background: 'transparent',
      font: '400 13px var(--font-sans)',
      color: glass ? 'var(--white)' : 'var(--text-strong)'
    }
  }), /*#__PURE__*/React.createElement("button", {
    type: "submit",
    style: {
      height: 34,
      padding: '0 18px',
      border: 0,
      borderRadius: 'var(--radius-pill)',
      background: 'var(--accent)',
      color: 'var(--white)',
      font: '500 13px var(--font-sans)',
      cursor: 'pointer'
    }
  }, buttonLabel));
}
Object.assign(__ds_scope, { SearchBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/SearchBar.jsx", error: String((e && e.message) || e) }); }

// components/navigation/CarouselControls.jsx
try { (() => {
function CarouselControls({
  onPrev,
  onNext,
  canPrev = true,
  canNext = true,
  size = 36,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "chevron-left",
    variant: "outline",
    size: size,
    label: "Previous",
    onClick: onPrev,
    disabled: !canPrev
  }), /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "chevron-right",
    variant: "accent",
    size: size,
    label: "Next",
    onClick: onNext,
    disabled: !canNext
  }));
}
Object.assign(__ds_scope, { CarouselControls });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/CarouselControls.jsx", error: String((e && e.message) || e) }); }

// components/navigation/NavBar.jsx
try { (() => {
function NavBar({
  links = ['Explore Hotels', 'Deals & Offers', 'Destinations'],
  active,
  ctaLabel = 'Sign In',
  onCta,
  onNavigate,
  tone = 'light',
  brand,
  style
}) {
  const fg = tone === 'light' ? 'var(--white)' : 'var(--text-strong)';
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 24,
      padding: '20px 0',
      borderBottom: `1px solid ${tone === 'light' ? 'var(--border-inverse)' : 'var(--border-subtle)'}`,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 32
    }
  }, brand && /*#__PURE__*/React.createElement("span", {
    style: {
      font: '500 18px var(--font-sans)',
      letterSpacing: '-0.03em',
      color: fg
    }
  }, brand), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 28
    }
  }, links.map(l => /*#__PURE__*/React.createElement("a", {
    key: l,
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNavigate && onNavigate(l);
    },
    style: {
      font: `${active === l ? 500 : 400} 13px var(--font-sans)`,
      color: fg,
      opacity: active && active !== l ? .75 : 1,
      textDecoration: 'none',
      whiteSpace: 'nowrap'
    }
  }, l)))), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    size: "sm",
    onClick: onCta
  }, ctaLabel));
}
Object.assign(__ds_scope, { NavBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/NavBar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Community.jsx
try { (() => {
function Community() {
  const {
    SectionHeader,
    Button,
    Icon,
    LogoStrip,
    NewsletterCard
  } = window.HostNexusDesignSystem_229e3d;
  const [done, setDone] = React.useState(false);
  const Ph = ({
    id,
    w,
    h,
    y
  }) => /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: w,
      height: h,
      flexShrink: 0,
      borderRadius: 'var(--radius-lg)',
      overflow: 'hidden',
      transform: `translateY(${y}px)`,
      background: 'var(--ink-100)'
    }
  }, /*#__PURE__*/React.createElement(Slot, {
    id: id,
    label: "Stay"
  }));
  return /*#__PURE__*/React.createElement("section", {
    "data-screen-label": "Community",
    style: {
      background: 'var(--surface-page)',
      padding: 'var(--section-y) 0',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement(Container, {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 28
    }
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    align: "center",
    eyebrow: "Explore Hotels",
    title: /*#__PURE__*/React.createElement(React.Fragment, null, "Trusted Stays, Seamless", /*#__PURE__*/React.createElement("br", null), "Booking Explore Now!"),
    description: "Discover top hotels near you with just a tap\u2014effortless booking, ultimate comfort."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Button, {
    arrow: true
  }, "Get Started"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      whiteSpace: 'nowrap',
      font: '400 12px var(--font-sans)',
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "shield-check",
    size: 14
  }), "Pause or cancel service anytime"))), /*#__PURE__*/React.createElement(LogoStrip, {
    logos: window.HN_DATA.partners,
    style: {
      margin: '48px 0 56px'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      gap: 40
    }
  }, /*#__PURE__*/React.createElement(Ph, {
    id: "rail-1",
    w: 200,
    h: 220,
    y: -20
  }), /*#__PURE__*/React.createElement(Ph, {
    id: "rail-2",
    w: 260,
    h: 250,
    y: 10
  }), done ? /*#__PURE__*/React.createElement("div", {
    style: {
      width: 400,
      flexShrink: 0,
      background: 'var(--surface-card-dark)',
      borderRadius: 'var(--radius-lg)',
      padding: 32,
      boxSizing: 'border-box',
      textAlign: 'center',
      color: '#fff',
      font: '400 18px/1.5 var(--font-sans)'
    }
  }, "Welcome aboard. Your first stay picks arrive this week.") : /*#__PURE__*/React.createElement(NewsletterCard, {
    width: 400,
    style: {
      flexShrink: 0
    },
    placeholder: "support@hostnexus.com",
    onSubmit: () => setDone(true)
  }), /*#__PURE__*/React.createElement(Ph, {
    id: "rail-3",
    w: 260,
    h: 250,
    y: 40
  }), /*#__PURE__*/React.createElement(Ph, {
    id: "rail-4",
    w: 200,
    h: 220,
    y: -10
  })));
}
window.Community = Community;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Community.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Destinations.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Destinations() {
  const {
    SectionHeader,
    Button,
    DestinationCard
  } = window.HostNexusDesignSystem_229e3d;
  const d = window.HN_DATA.destinations;
  return /*#__PURE__*/React.createElement("section", {
    "data-screen-label": "Destinations",
    style: {
      background: 'var(--surface-muted)',
      padding: 'var(--section-y) 0'
    }
  }, /*#__PURE__*/React.createElement(Container, {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 56
    }
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    title: /*#__PURE__*/React.createElement(React.Fragment, null, "Our most Amazing", /*#__PURE__*/React.createElement("br", null), "Destination"),
    action: /*#__PURE__*/React.createElement(Button, {
      variant: "outline",
      arrow: true,
      size: "sm"
    }, "Explore Now")
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1.85fr) minmax(0,1fr)',
      gridTemplateRows: '260px 260px',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(DestinationCard, _extends({
    size: "lg",
    height: "100%",
    style: {
      gridRow: '1 / 3'
    }
  }, d[0], {
    media: /*#__PURE__*/React.createElement(Slot, {
      id: "dest-1",
      label: "Feature destination"
    })
  })), /*#__PURE__*/React.createElement(DestinationCard, _extends({
    height: "100%"
  }, d[1], {
    media: /*#__PURE__*/React.createElement(Slot, {
      id: "dest-2",
      label: "Destination"
    })
  })), /*#__PURE__*/React.createElement(DestinationCard, _extends({
    height: "100%"
  }, d[2], {
    media: /*#__PURE__*/React.createElement(Slot, {
      id: "dest-3",
      label: "Destination"
    })
  })))));
}
window.Destinations = Destinations;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Destinations.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Faq.jsx
try { (() => {
function Faq() {
  const {
    Eyebrow,
    Accordion
  } = window.HostNexusDesignSystem_229e3d;
  return /*#__PURE__*/React.createElement("section", {
    "data-screen-label": "FAQ",
    style: {
      background: 'var(--surface-page)',
      padding: 'var(--section-y) 0'
    }
  }, /*#__PURE__*/React.createElement(Container, {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 48
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-end',
      gap: 32,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "FAQs"), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      font: '400 var(--text-h2)/1.1 var(--font-sans)',
      letterSpacing: 'var(--tracking-heading)'
    }
  }, "Got Questions?", /*#__PURE__*/React.createElement("br", null), "We\u2019re Here to Help.")), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      maxWidth: 360,
      font: '400 14px/1.55 var(--font-sans)',
      color: 'var(--text-body)'
    }
  }, "Find quick answers to common questions about booking, cancellations, payments, and more \u2014 so you can travel with confidence.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1fr) minmax(0,1fr)',
      gap: 48,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(Accordion, {
    items: window.HN_DATA.faqs
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: 480,
      borderRadius: 'var(--radius-md)',
      overflow: 'hidden',
      background: 'var(--ink-100)'
    }
  }, /*#__PURE__*/React.createElement(Slot, {
    id: "faq-photo",
    label: "Lifestyle photo"
  })))));
}
window.Faq = Faq;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Faq.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Footer.jsx
try { (() => {
function Footer() {
  const {
    Button
  } = window.HostNexusDesignSystem_229e3d;
  const link = {
    font: '400 13px var(--font-sans)',
    color: 'rgba(255,255,255,.85)',
    textDecoration: 'none',
    whiteSpace: 'nowrap'
  };
  return /*#__PURE__*/React.createElement("footer", {
    "data-screen-label": "Footer",
    style: {
      position: 'relative',
      background: 'var(--ink-950)',
      color: '#fff',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement(Slot, {
    id: "footer-bg",
    label: "Footer photo \u2014 cabin in forest at night"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'linear-gradient(180deg,rgba(11,13,17,.7),rgba(11,13,17,.4) 50%,rgba(11,13,17,.8))',
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement(Container, {
    style: {
      position: 'relative',
      pointerEvents: 'none',
      paddingTop: 112,
      paddingBottom: 32,
      display: 'flex',
      flexDirection: 'column',
      gap: 64
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      font: '400 var(--text-display-l)/1.05 var(--font-sans)',
      letterSpacing: 'var(--tracking-display)'
    }
  }, "Discover Places You\u2019ll", /*#__PURE__*/React.createElement("br", null), "Never Want to Leave"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      maxWidth: 560,
      font: '400 14px/1.55 var(--font-sans)',
      color: 'var(--text-inverse-muted)'
    }
  }, "Your next great stay is waiting. Explore a wide range of handpicked hotels and cozy stays, all tailored to make your journey smooth and memorable. Booking has never been this easy."), /*#__PURE__*/React.createElement("div", {
    style: {
      pointerEvents: 'auto',
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "lg"
  }, "Plan Your Stay"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-end',
      gap: 24,
      pointerEvents: 'auto',
      marginTop: 80
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: '400 13px/1.5 var(--font-sans)'
    }
  }, "HostNexus HQ", /*#__PURE__*/React.createElement("br", null), "45 Greenview Avenue,", /*#__PURE__*/React.createElement("br", null), "New York, NY 10001, USA", /*#__PURE__*/React.createElement("br", null), "Email: support@hostnexus.com", /*#__PURE__*/React.createElement("br", null), "Phone: +1 (212) 555-0134"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 40
    }
  }, ['Facebook', 'Instagram', 'Youtube', 'Twitter', 'LinkedIn'].map(s => /*#__PURE__*/React.createElement("a", {
    key: s,
    href: "#",
    style: link
  }, s)))), /*#__PURE__*/React.createElement("div", {
    style: {
      font: '500 clamp(96px,17.5vw,236px)/0.8 var(--font-sans)',
      letterSpacing: '-0.055em',
      textAlign: 'center',
      whiteSpace: 'nowrap',
      margin: '-24px 0 0'
    }
  }, "HostNexus"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: 24,
      pointerEvents: 'auto'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: link
  }, "\xA92026 HostNexus. All Rights Reserved"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 40
    }
  }, ['Privacy Policy', 'Terms of Use', 'Legal Disclaimer', 'Cookie Policy'].map(s => /*#__PURE__*/React.createElement("a", {
    key: s,
    href: "#",
    style: link
  }, s))))));
}
window.Footer = Footer;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Footer.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Hero.jsx
try { (() => {
function Hero({
  onSearch
}) {
  const {
    NavBar,
    SearchBar
  } = window.HostNexusDesignSystem_229e3d;
  const y = useScrollY();
  const [loaded, setLoaded] = React.useState(false);
  React.useEffect(() => {
    requestAnimationFrame(() => setLoaded(true));
  }, []);
  return /*#__PURE__*/React.createElement("section", {
    "data-screen-label": "Hero",
    style: {
      position: 'relative',
      height: 760,
      background: 'var(--night-900)',
      overflow: 'hidden',
      color: '#fff'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      transform: `translateY(${y * 0.25}px) scale(${loaded ? 1 : 1.08})`,
      transition: 'transform 1600ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement(Slot, {
    id: "hero-bg",
    label: "Hero photo \u2014 architecture at blue hour"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'var(--overlay-hero)',
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      right: 0,
      top: 84,
      textAlign: 'center',
      font: '500 var(--text-wordmark)/0.9 var(--font-sans)',
      letterSpacing: '-0.05em',
      color: 'rgba(255,255,255,.22)',
      whiteSpace: 'nowrap',
      pointerEvents: 'none',
      transform: `translateY(${y * 0.45}px)`,
      opacity: Math.max(0, 1 - y / 500)
    }
  }, "HostNexus"), /*#__PURE__*/React.createElement(Container, {
    reveal: false,
    style: {
      position: 'relative',
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'space-between',
      pointerEvents: 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      pointerEvents: 'auto'
    }
  }, /*#__PURE__*/React.createElement(NavBar, {
    active: "Explore Hotels"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      gap: 32,
      paddingBottom: 56,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      ...revealStyle(loaded, 200),
      margin: 0,
      font: '400 var(--text-display-xl)/1.05 var(--font-sans)',
      letterSpacing: 'var(--tracking-display)'
    }
  }, "Find Your Perfect Stay", /*#__PURE__*/React.createElement("br", null), "at the Best Price"), /*#__PURE__*/React.createElement("div", {
    style: {
      pointerEvents: 'auto',
      paddingBottom: 12
    }
  }, /*#__PURE__*/React.createElement(SearchBar, {
    width: 340,
    onSubmit: onSearch
  })))));
}
window.Hero = Hero;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Hero.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Listings.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Listings({
  query,
  onClear,
  sectionRef
}) {
  const {
    SectionHeader,
    CarouselControls,
    ListingCard,
    Button
  } = window.HostNexusDesignSystem_229e3d;
  const all = window.HN_DATA.listings;
  const q = (query || '').toLowerCase();
  const items = q ? all.filter(l => (l.title + ' ' + l.location).toLowerCase().includes(q)) : all;
  const rail = React.useRef();
  const [pos, setPos] = React.useState(0);
  const W = 276;
  const go = dir => {
    const n = Math.max(0, Math.min(items.length - 1, pos + dir));
    setPos(n);
    rail.current.scrollTo({
      left: n * W,
      behavior: 'smooth'
    });
  };
  React.useEffect(() => {
    setPos(0);
    rail.current && rail.current.scrollTo({
      left: 0
    });
  }, [query]);
  return /*#__PURE__*/React.createElement("section", {
    "data-screen-label": "Listings",
    ref: sectionRef,
    style: {
      background: 'var(--surface-page)',
      padding: 'var(--section-y) 0'
    }
  }, /*#__PURE__*/React.createElement(Container, {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 48
    }
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    eyebrow: query ? /*#__PURE__*/React.createElement("span", null, "Results for \u201C", query, "\u201D \xB7 ", /*#__PURE__*/React.createElement("a", {
      href: "#",
      onClick: e => {
        e.preventDefault();
        onClear();
      },
      style: {
        color: 'var(--accent)'
      }
    }, "Clear")) : null,
    title: /*#__PURE__*/React.createElement(React.Fragment, null, "Discover Your", /*#__PURE__*/React.createElement("br", null), "Ideal Destination"),
    action: /*#__PURE__*/React.createElement(CarouselControls, {
      onPrev: () => go(-1),
      onNext: () => go(1),
      canPrev: pos > 0,
      canNext: pos < items.length - 1
    })
  }), /*#__PURE__*/React.createElement("div", {
    ref: rail,
    style: {
      display: 'flex',
      gap: 16,
      overflowX: 'hidden',
      marginRight: 'calc(-1 * var(--gutter))'
    }
  }, items.map(l => /*#__PURE__*/React.createElement(ListingCard, _extends({
    key: l.id,
    width: 260,
    style: {
      flexShrink: 0
    },
    imageHeight: 240
  }, l, {
    media: /*#__PURE__*/React.createElement(Slot, {
      id: 'listing-' + l.id,
      label: "Property photo"
    })
  }))), !items.length && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '40px 0',
      font: '400 16px var(--font-sans)',
      color: 'var(--text-muted)',
      display: 'flex',
      gap: 16,
      alignItems: 'center'
    }
  }, "No stays match \u201C", query, "\u201D. ", /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    size: "sm",
    onClick: onClear
  }, "Show all")))));
}
window.Listings = Listings;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Listings.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Shared.jsx
try { (() => {
const Slot = ({
  id,
  label
}) => /*#__PURE__*/React.createElement("image-slot", {
  id: id,
  shape: "rect",
  placeholder: label || 'Drop image',
  style: {
    position: 'absolute',
    inset: 0,
    width: '100%',
    height: '100%'
  }
});
const reduced = () => window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
function useReveal(threshold = 0.15) {
  const ref = React.useRef();
  const [on, setOn] = React.useState(reduced());
  React.useEffect(() => {
    if (on || !ref.current) return;
    const io = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) {
        setOn(true);
        io.disconnect();
      }
    }, {
      threshold
    });
    io.observe(ref.current);
    return () => io.disconnect();
  }, []);
  return [ref, on];
}
const revealStyle = (on, delay = 0) => ({
  opacity: on ? 1 : 0,
  filter: on ? 'blur(0)' : 'blur(12px)',
  transform: on ? 'none' : 'translateY(24px)',
  transition: `opacity var(--dur-reveal) var(--ease-out) ${delay}ms,filter var(--dur-reveal) var(--ease-out) ${delay}ms,transform var(--dur-reveal) var(--ease-out) ${delay}ms`
});
const Container = ({
  children,
  style,
  reveal = true
}) => {
  const [ref, on] = useReveal();
  return /*#__PURE__*/React.createElement("div", {
    ref: ref,
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '0 var(--gutter)',
      boxSizing: 'border-box',
      ...(reveal ? revealStyle(on) : {}),
      ...style
    }
  }, children);
};
function useScrollY() {
  const [y, setY] = React.useState(0);
  React.useEffect(() => {
    if (reduced()) return;
    let r;
    const on = () => {
      cancelAnimationFrame(r);
      r = requestAnimationFrame(() => setY(window.scrollY));
    };
    window.addEventListener('scroll', on, {
      passive: true
    });
    return () => window.removeEventListener('scroll', on);
  }, []);
  return y;
}
Object.assign(window, {
  Slot,
  Container,
  useReveal,
  revealStyle,
  useScrollY
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Shared.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Story.jsx
try { (() => {
function Story() {
  const {
    Eyebrow,
    Button
  } = window.HostNexusDesignSystem_229e3d;
  const ref = React.useRef();
  const [p, setP] = React.useState(0);
  React.useEffect(() => {
    const on = () => {
      const r = ref.current.getBoundingClientRect();
      const vh = window.innerHeight;
      setP(Math.max(0, Math.min(1, (vh * 0.9 - r.top) / (vh * 0.6))));
    };
    on();
    window.addEventListener('scroll', on, {
      passive: true
    });
    return () => window.removeEventListener('scroll', on);
  }, []);
  const words = 'From city escapes to beachside retreats, we connect you with hotels that fit your lifestyle wherever the journey takes you.'.split(' ');
  const lit = Math.round(p * words.length);
  return /*#__PURE__*/React.createElement("section", {
    "data-screen-label": "Our Story",
    ref: ref,
    style: {
      background: 'var(--surface-page)',
      padding: 'var(--section-y) 0'
    }
  }, /*#__PURE__*/React.createElement(Container, {
    style: {
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1fr) minmax(0,1.6fr)',
      gap: 64
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'space-between',
      gap: 48
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "Our Story"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      maxWidth: 340,
      font: '400 14px/1.6 var(--font-sans)',
      color: 'var(--text-body)'
    }
  }, "Trusted by over ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-strong)',
      fontWeight: 600
    }
  }, "10 million travelers"), " worldwide, we\u2019re proud to deliver top-rated stays with an average ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-strong)',
      fontWeight: 600
    }
  }, "rating of 4.8\u2605"), ". Your comfort and satisfaction are always our top priority.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 40,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      font: '400 var(--text-h3)/1.18 var(--font-sans)',
      letterSpacing: 'var(--tracking-heading)'
    }
  }, words.map((w, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      color: i < lit ? 'var(--text-strong)' : 'var(--ink-400)',
      transition: 'color var(--dur-base)'
    }
  }, w, " "))), /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    arrow: true
  }, "Learn More"))));
}
window.Story = Story;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Story.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Testimonials.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Testimonials() {
  const {
    Eyebrow,
    CarouselControls,
    Testimonial
  } = window.HostNexusDesignSystem_229e3d;
  const t = window.HN_DATA.testimonials;
  const [i, setI] = React.useState(0);
  return /*#__PURE__*/React.createElement("section", {
    "data-screen-label": "Testimonials",
    style: {
      background: 'var(--surface-subtle)',
      padding: 'var(--section-y) 0'
    }
  }, /*#__PURE__*/React.createElement(Container, {
    style: {
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1fr) minmax(0,1.4fr)',
      gap: 64
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'space-between',
      gap: 48
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "Testimonial"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      maxWidth: 440,
      font: '400 var(--text-body-lg)/1.4 var(--font-sans)',
      color: 'var(--text-body)'
    }
  }, "Here\u2019s what people have to say about working together. Real moments, real experiences, real feedback.")), /*#__PURE__*/React.createElement(CarouselControls, {
    onPrev: () => setI(i - 1),
    onNext: () => setI(i + 1),
    canPrev: i > 0,
    canNext: i < t.length - 1
  })), /*#__PURE__*/React.createElement(Testimonial, _extends({
    key: i
  }, t[i], {
    avatar: /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative',
        width: '100%',
        height: '100%'
      }
    }, /*#__PURE__*/React.createElement("image-slot", {
      id: 'avatar-' + i,
      shape: "circle",
      placeholder: "",
      style: {
        position: 'absolute',
        inset: 0,
        width: '100%',
        height: '100%'
      }
    }))
  }))));
}
window.Testimonials = Testimonials;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Testimonials.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/data.js
try { (() => {
window.HN_DATA = {
  destinations: [{
    id: 'd1',
    title: 'Vista Grand Suites',
    location: 'Phuket, Thailand',
    rating: 4.9
  }, {
    id: 'd2',
    title: 'Mountain Peak Lodge',
    location: 'Aspen, Colorado',
    rating: 4.9
  }, {
    id: 'd3',
    title: 'Ocean View Resort',
    location: 'Bali, Indonesia',
    rating: 4.8
  }],
  listings: [{
    id: 'l1',
    title: 'City Center Apartments',
    price: '$150,000',
    location: 'New York, USA'
  }, {
    id: 'l2',
    title: 'Tropical Paradise Resort',
    price: '$110,000',
    location: 'Maui, Hawaii'
  }, {
    id: 'l3',
    title: 'Pinecone Lodge',
    price: '$85,000',
    location: 'Lake Tahoe, California'
  }, {
    id: 'l4',
    title: 'Lakeside Retreat',
    price: '$96,000',
    location: 'Lake Como, Italy'
  }, {
    id: 'l5',
    title: 'Harbor Loft',
    price: '$132,000',
    location: 'Sydney, Australia'
  }, {
    id: 'l6',
    title: 'Desert Mirage Villa',
    price: '$120,000',
    location: 'Dubai, UAE'
  }],
  partners: [{
    name: 'PARTNER ONE'
  }, {
    name: 'Partner Two'
  }, {
    name: 'PARTNER THREE'
  }, {
    name: 'Partner Four'
  }, {
    name: 'PARTNER FIVE'
  }, {
    name: 'Partner Six'
  }],
  testimonials: [{
    headline: 'Exactly What We Needed — Smooth & Stress-Free!',
    body: 'The booking process was incredibly smooth, and the hotel was exactly as shown. Clean, comfortable, and located right where we needed. This platform made our vacation stress-free!',
    author: 'Sarah Ahmed',
    rating: 5
  }, {
    headline: 'Found a Hidden Gem in Minutes.',
    body: 'I searched, compared and booked a lakeside cabin in under five minutes. The price was lower than anywhere else I looked.',
    author: 'Daniel Ruiz',
    rating: 4.9
  }, {
    headline: 'Our Go-To for Every Trip Now.',
    body: 'From city weekends to beach holidays, every stay we have booked has matched the photos and the reviews.',
    author: 'Mei Tanaka',
    rating: 5
  }],
  faqs: [{
    q: 'How do I find the best deals on HostNexus?',
    a: 'We compare prices from hundreds of trusted travel sites in real-time to help you find the best deal for your ideal stay whether it’s a luxury resort or a cozy cabin.'
  }, {
    q: 'Is it safe to book through HostNexus?',
    a: 'Yes. Payments are encrypted and every property is verified before it is listed.'
  }, {
    q: 'Can I cancel or change my reservation?',
    a: 'Most stays offer free cancellation up to 48 hours before check-in. Check the policy on each listing.'
  }, {
    q: 'Do I need an account to book?',
    a: 'No — you can book as a guest. An account lets you save stays and manage bookings in one place.'
  }, {
    q: 'Are taxes and fees included in the prices shown?',
    a: 'The final price, including taxes and fees, is always shown before you pay.'
  }, {
    q: 'How do I contact customer support?',
    a: 'Email support@hostnexus.com or call +1 (212) 555-0134, any day of the week.'
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/data.js", error: String((e && e.message) || e) }); }

// ui_kits/website/image-slot.js
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)
// Copied omelette starter. Re-running copy_starter_component with this kind overwrites this file with the latest version (page content is unaffected).
/* BEGIN USAGE */
/**
 * <image-slot> — user-fillable image placeholder.
 *
 * Drop this into a deck, mockup, or page wherever a design needs an image.
 * You control the slot's shape; it sizes to its container by default. When the search_stock_photos tool
 * is available, prefill the slot by default — write the photo's URL into
 * src (with credit/credit-href); the user can still fill or replace it
 * by dragging an image file onto it (or clicking to browse). The dropped
 * image persists across reloads via a .image-slots.state.json sidecar —
 * same read-via-fetch / write-via-window.omelette pattern as
 * design_canvas.jsx, so the filled slot shows on share links, downloaded
 * zips, and PPTX export. Outside the omelette runtime the slot is read-only.
 *
 * The sidecar is a SIBLING of the HTML file that uses this component: the
 * read is a document-relative fetch, and the host resolves the bridge's
 * sidecar writes into the previewed file's directory to match (same
 * contract as design_canvas.jsx). Pages in the same directory share one
 * sidecar; keep slot ids distinct across them.
 *
 * Attributes:
 *   id           Persistence key. REQUIRED for the drop to survive reload —
 *                every slot on the page needs a distinct id.
 *   shape        'rect' | 'rounded' | 'circle' | 'pill'   (default 'rounded')
 *                'circle' applies 50% border-radius; on a non-square slot
 *                that's an ellipse — set equal width and height for a true
 *                circle.
 *   radius       Corner radius in px for 'rounded'.       (default 12)
 *   mask         Any CSS clip-path value. Overrides `shape` — use this for
 *                hexagons, blobs, arbitrary polygons.
 *   fit          Initial framing baseline: cover | contain.   (default 'cover')
 *                cover starts the image filling the frame (overflow cropped);
 *                contain starts it fully visible (letterboxed). Either way the
 *                user can always pan/scale from there — double-click, or the
 *                Edit control, enters reframe mode (drag to move, scroll or
 *                corner-handles to scale; Escape / click-out commits). The
 *                crop persists alongside the image in the sidecar.
 *   placeholder  Empty-state caption.                      (default 'Drop an image')
 *   src          Optional initial/fallback image URL. Prefill it with a real
 *                photo via search_stock_photos when that tool is available
 *                (set credit/credit-href from the result). A user drop
 *                overrides it; clearing the drop reveals src again.
 *   credit       Attribution text shown as a small overlay at the
 *                bottom-left of the filled slot. REQUIRED whenever src
 *                points at any Unsplash host (images.unsplash.com,
 *                plus.unsplash.com, …): an Unsplash src with no credit
 *                renders an error tile INSTEAD of the photo (Unsplash
 *                terms forbid showing their photos unattributed). Use the
 *                exact form 'Photo by {photographer name} on Unsplash' —
 *                the overlay then links the name to credit-href and
 *                'Unsplash' to the Unsplash homepage, and links back to
 *                unsplash.com automatically get the required utm referral
 *                params appended at render time. The credit belongs to
 *                the src image, so it only shows while src is what's
 *                displayed — a user-dropped image hides it.
 *   credit-href  Link for the photographer's name in the credit overlay
 *                (their Unsplash profile URL from the stock-photo search
 *                results). http(s) URLs only — anything else renders the
 *                name as plain text.
 *
 * Sizing: the slot fills its container by default (width/height 100%).
 * Put it in a sized wrapper — absolutely positioned, a grid cell, a fixed
 * frame — and it takes exactly that box. When the parent's height is
 * indefinite (ordinary flow), it falls back to full width at a 3:2 aspect
 * ratio instead of collapsing. In a shrink-to-fit parent (a float,
 * width:max-content, an unsized absolute wrapper), percentages have
 * nothing to resolve against — size the slot or its wrapper explicitly
 * there. For a fixed-size slot, set
 * width/height on the element itself (inline style), which overrides the
 * default. When
 * layering content above a slot (full-bleed layouts), make the overlay
 * click-through — pointer-events: none on scrims/text plates, re-enabled
 * on interactive children — so the slot's hover controls stay reachable.
 * Keep the slot's bottom-left corner visually clear as well: the credit
 * overlay renders there, and a dark fade or text plate covering it hides
 * the attribution Unsplash's terms require — end the fade above that
 * corner, or keep it nearly transparent where the credit sits.
 *
 * Usage:
 *   <div style="position:relative;width:100%;height:100%">      <!-- full-bleed: -->
 *     <image-slot id="bg" shape="rect"></image-slot>            <!-- fills the wrapper -->
 *   </div>
 *   <image-slot id="hero"   style="width:800px;height:450px" shape="rounded" radius="20"
 *               placeholder="Drop a hero image"></image-slot>
 *   <image-slot id="avatar" style="width:120px;height:120px" shape="circle"></image-slot>
 *   <image-slot id="kite"   style="width:300px;height:300px"
 *               mask="polygon(50% 0, 100% 50%, 50% 100%, 0 50%)"></image-slot>
 */
/* END USAGE */

(() => {
  const STATE_FILE = '.image-slots.state.json';

  // Unsplash terms require visible attribution wherever their photos
  // display, and every link back to unsplash.com must carry utm referral
  // params. Two render-time rules enforce that here:
  //  - an Unsplash-src slot with NO credit attribute renders an error
  //    tile INSTEAD of the photo (an uncredited Unsplash photo on screen
  //    is itself the terms violation, so it never renders bare);
  //  - rendered credit links pointing at unsplash.com get the referral
  //    params appended when absent (credit-href values live in page
  //    content that can't be edited after the fact).
  // Keep the utm_source value in sync with UTM_SOURCE in
  // platform/web-agent/unsplash.ts — this file is a project-local
  // artifact and cannot import it (equality is pinned by tests).
  const UNSPLASH_HOMEPAGE_HREF = 'https://unsplash.com/?utm_source=claude_design&utm_medium=referral';
  // Host rule mirrors the hotlink validator that admits Unsplash srcs into
  // pages in the first place (cdn$ in unsplash.ts: apex or any subdomain)
  // — Unsplash+ results serve from plus.unsplash.com, not just images.*,
  // and an admitted-but-uncredited photo must error whatever unsplash
  // host it rides on.
  // Trailing-dot FQDNs (images.unsplash.com.) are the same host to the
  // browser but would miss the regex — strip one dot so the check fails
  // CLOSED (unrecognized-but-real Unsplash srcs must error, not render).
  const isUnsplashHost = u => {
    try {
      return /(^|\.)unsplash\.com$/.test(new URL(u, document.baseURI).hostname.replace(/\.$/, ''));
    } catch {
      return false;
    }
  };
  // Render-time referral normalization for links back to Unsplash:
  // appends utm_source/utm_medium when absent, preserves every existing
  // query param, never overwrites an existing utm_source, and passes
  // non-Unsplash URLs through untouched. Input is an ABSOLUTE validated
  // http(s) URL (the credit render funnel resolves + validates first).
  const withReferral = href => {
    try {
      const u = new URL(href);
      if (!/(^|\.)unsplash\.com$/.test(u.hostname.replace(/\.$/, ''))) {
        return href;
      }
      if (!u.searchParams.has('utm_source')) {
        u.searchParams.set('utm_source', 'claude_design');
      }
      if (!u.searchParams.has('utm_medium')) {
        u.searchParams.set('utm_medium', 'referral');
      }
      return u.toString();
    } catch (e) {
      return href;
    }
  };
  // 2× a ~600px slot in a 1920-wide deck — retina-sharp without making the
  // sidecar enormous. A 1200px WebP at q=0.85 is ~150-300KB.
  const MAX_DIM = 1200;
  // Raster formats only. SVG is excluded (can carry script; createImageBitmap
  // on SVG blobs is inconsistent). GIF is excluded because the canvas
  // re-encode keeps only the first frame, so an animated GIF would silently
  // go still — better to reject than surprise.
  const ACCEPT = ['image/png', 'image/jpeg', 'image/webp', 'image/avif'];

  // ── Shared sidecar store ────────────────────────────────────────────────
  // One fetch + immediate write-on-change for every <image-slot> on the
  // page. Reads via fetch() so viewing works anywhere the HTML and sidecar
  // are served together; writes go through window.omelette.writeFile, which
  // the host allowlists to *.state.json basenames only.
  const subs = new Set();
  let slots = {};
  // ids explicitly cleared before the sidecar fetch resolved — otherwise
  // the merge below can't tell "never set" from "just deleted" and would
  // resurrect the sidecar's stale value.
  const tombstones = new Set();
  let loaded = false;
  let loadP = null;
  function load() {
    if (loadP) return loadP;
    loadP = fetch(STATE_FILE).then(r => r.ok ? r.json() : null).then(j => {
      // Merge: sidecar loses to any in-memory change that raced ahead of
      // the fetch (drop or clear) so neither is clobbered by hydration.
      if (j && typeof j === 'object') {
        const merged = Object.assign({}, j, slots);
        // A framing-only write that raced ahead of hydration must not
        // drop a user image that's only on disk — inherit u from the
        // sidecar for any in-memory entry that lacks one.
        for (const k in slots) {
          if (merged[k] && !merged[k].u && j[k]) {
            merged[k].u = typeof j[k] === 'string' ? j[k] : j[k].u;
          }
        }
        for (const id of tombstones) delete merged[id];
        slots = merged;
      }
      tombstones.clear();
    }).catch(() => {}).then(() => {
      loaded = true;
      subs.forEach(fn => fn());
    });
    return loadP;
  }

  // Serialize writes so two near-simultaneous drops on different slots
  // can't reorder at the backend and leave the sidecar with only the
  // first. A save requested mid-flight just marks dirty and re-fires on
  // completion with the then-current slots.
  let saving = false;
  let saveDirty = false;
  // Unload-time flush: save()'s serialization defers a mid-RTT re-fire to a
  // .then that never runs in an unloading document, silently dropping a
  // pagehide commit. Post the current slots immediately instead — content
  // is a superset snapshot of any in-flight save's, the write is a
  // whole-file last-writer-wins replace, and postMessage FIFO delivers it
  // to the host after the in-flight one, so a backend-side reorder at
  // worst reproduces the dropped-commit outcome this flush improves on.
  // Guarded on the initial sidecar read: pre-hydration slots can miss
  // other slots' persisted entries, and flushing it would clobber them —
  // that narrow case stays best-effort (the in-memory merge in load()
  // cannot happen in an unloading document anyway).
  function flushNow() {
    if (!loaded) return;
    const w = window.omelette && window.omelette.writeFile;
    if (!w) return;
    try {
      Promise.resolve(w(STATE_FILE, JSON.stringify(slots))).catch(() => {});
    } catch (e) {}
  }
  function save() {
    if (saving) {
      saveDirty = true;
      return;
    }
    const w = window.omelette && window.omelette.writeFile;
    if (!w) return;
    saving = true;
    Promise.resolve(w(STATE_FILE, JSON.stringify(slots))).catch(() => {}).then(() => {
      saving = false;
      if (saveDirty) {
        saveDirty = false;
        save();
      }
    });
  }
  const S_MAX = 5;
  const clampS = s => Math.max(1, Math.min(S_MAX, s));

  // Normalize a stored slot value. Pre-reframe sidecars stored a bare
  // data-URL string; newer ones store {u, s, x, y}. Either shape is valid.
  function getSlot(id) {
    const v = slots[id];
    if (!v) return null;
    return typeof v === 'string' ? {
      u: v,
      s: 1,
      x: 0,
      y: 0
    } : v;
  }
  function setSlot(id, val) {
    if (!id) return;
    if (val) {
      slots[id] = val;
      tombstones.delete(id);
    } else {
      delete slots[id];
      if (!loaded) tombstones.add(id);
    }
    subs.forEach(fn => fn());
    // A drop is rare + high-value — write immediately so nav-away can't lose
    // it. Gate on the initial read so we don't overwrite a sidecar we haven't
    // merged yet; the merge in load() keeps this change once the read lands.
    if (loaded) save();else load().then(save);
  }

  // ── Image downscale ─────────────────────────────────────────────────────
  // Encode through a canvas so the sidecar carries resized bytes, not the
  // raw upload. Longest side is capped at 2× the slot's rendered width
  // (retina) and at MAX_DIM. WebP keeps alpha and is ~10× smaller than PNG
  // for photos, so there's no need for per-image format picking.
  async function toDataUrl(file, targetW) {
    const bitmap = await createImageBitmap(file);
    try {
      const cap = Math.min(MAX_DIM, Math.max(1, Math.round(targetW * 2)) || MAX_DIM);
      const scale = Math.min(1, cap / Math.max(bitmap.width, bitmap.height));
      const w = Math.max(1, Math.round(bitmap.width * scale));
      const h = Math.max(1, Math.round(bitmap.height * scale));
      const canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      canvas.getContext('2d').drawImage(bitmap, 0, 0, w, h);
      return canvas.toDataURL('image/webp', 0.85);
    } finally {
      bitmap.close && bitmap.close();
    }
  }

  // ── Custom element ──────────────────────────────────────────────────────
  const stylesheet =
  // Fill the container by default: slots are usually placed inside a
  // sized wrapper (a hero frame, a grid cell, an inset:0 layer) and are
  // expected to take that box — a fixed intrinsic size would render as
  // a small tile in the corner of a full-bleed wrapper instead.
  // aspect-ratio is the companion fallback that keeps a bare slot
  // visible when the parent's height is indefinite: height:100%
  // resolves to auto there, and the ratio then derives height from
  // width instead of letting the slot collapse to zero height.
  // Explicit width/height on the element override all of this.
  // color:inherit (not a fixed near-black): the placeholder chrome —
  // empty-state icon/caption (currentColor) and the dashed ring — must
  // read on dark decks too, and the slide's own text color is the one
  // color guaranteed to contrast with the slide background. The soft
  // look comes from opacity on those parts, not from a baked-in alpha.
  ':host{display:block;position:relative;' + '  font:13px/1.3 system-ui,-apple-system,sans-serif;' + '  width:100%;height:100%;aspect-ratio:3/2}' + '.empty .cap,.empty .sub{opacity:.75}' + '.frame{position:absolute;inset:0;overflow:hidden;background:rgba(127,127,127,.08)}' +
  // .frame img (clipped) and .spill (unclipped ghost + handles) share the
  // same left/top/width/height in frame-%, computed by _applyView(), so the
  // inside-mask crop and the outside-mask spill stay pixel-aligned.
  '.frame img{position:absolute;max-width:none;transform:translate(-50%,-50%);' + '  -webkit-user-drag:none;user-select:none;touch-action:none}' +
  // Reframe mode (double-click): the full image spills past the mask. The
  // spill layer is sized to the IMAGE bounds so its corners are where the
  // resize handles belong. The ghost <img> inside is translucent; the real
  // clipped <img> underneath shows the opaque in-mask crop.
  // popover=manual promotes the spill to the top layer on reframe, so it is
  // not clipped by any overflow:hidden / clip-path / scroll-container
  // ancestor (a plain z-index can't escape overflow clipping). UA popover
  // defaults (inset:0;margin:auto) are reset; _applyView sets viewport px.
  '.spill{position:fixed;margin:0;inset:auto;border:0;padding:0;background:transparent;' + '  overflow:visible;transform:translate(-50%,-50%);z-index:1;cursor:grab;touch-action:none}' + ':host([data-panning]) .spill{cursor:grabbing}' + '.spill .ghost{position:absolute;inset:0;width:100%;height:100%;opacity:.35;' + '  pointer-events:none;-webkit-user-drag:none;user-select:none;' + '  box-shadow:0 0 0 1px rgba(0,0,0,.2),0 12px 32px rgba(0,0,0,.2)}' + '.spill .handle{position:absolute;width:12px;height:12px;border-radius:50%;' + '  background:#fff;box-shadow:0 0 0 1.5px #c96442,0 1px 3px rgba(0,0,0,.3);' + '  transform:translate(-50%,-50%)}' + '.spill .handle[data-c=nw]{left:0;top:0;cursor:nwse-resize}' + '.spill .handle[data-c=ne]{left:100%;top:0;cursor:nesw-resize}' + '.spill .handle[data-c=sw]{left:0;top:100%;cursor:nesw-resize}' + '.spill .handle[data-c=se]{left:100%;top:100%;cursor:nwse-resize}' + ':host([data-reframe]){z-index:10}' + ':host([data-reframe]) .frame{box-shadow:0 0 0 2px #c96442}' + '.empty{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;' + '  justify-content:center;gap:6px;text-align:center;padding:12px;box-sizing:border-box;' + '  cursor:pointer;user-select:none}' + '.empty svg{opacity:.45}' + '.empty .cap{max-width:90%;font-weight:500;letter-spacing:.01em}' + '.empty .sub{font-size:11px}' + '.empty .sub u{text-underline-offset:2px}' + '.empty:hover .sub{opacity:1}' + ':host([data-over]) .frame{outline:2px solid #c96442;outline-offset:-2px;' + '  background:rgba(201,100,66,.10)}' + '.ring{position:absolute;inset:0;pointer-events:none;border:1.5px dashed currentColor;' + '  opacity:.35;transition:border-color .12s,opacity .12s}' + ':host([data-over]) .ring{border-color:#c96442;opacity:1}' + ':host([data-filled]) .ring{display:none}' +
  // Controls overlay INSIDE the frame, pinned to the top-right corner, so
  // a full-bleed slot in an overflow:hidden container still shows them
  // (the old below-mask placement got clipped). Credit sits bottom-left,
  // so top-right avoids collision. The blurred pill background keeps them
  // legible over the image.
  // The UA [popover] base rule styles the element in EVERY state (only
  // display:none is gated on :not(:popover-open), and the display:flex
  // below overrides that) — so the UA resets live HERE, like .spill's,
  // or the ordinary hover-state strip renders as a bordered Canvas box
  // centered by margin:auto. inset:auto precedes top/right (shorthand).
  '.ctl{position:absolute;inset:auto;top:8px;right:8px;margin:0;border:0;padding:0;' + '  background:transparent;overflow:visible;' + '  display:flex;gap:6px;opacity:0;pointer-events:none;transition:opacity .12s;z-index:2;' + '  white-space:nowrap}' +
  // While reframing, the spill owns the top layer and would swallow every
  // click on the in-frame controls. Promoting .ctl into the top layer
  // ABOVE the spill (shown after it — later popovers stack higher) keeps
  // Edit-as-toggle and Replace clickable mid-reframe. _applyView pins it
  // to the frame's top-right in viewport px (translateX(-100%)
  // right-aligns against the computed left edge); inset:auto clears the
  // base rule's top/right so the inline left/top position it alone.
  '.ctl:popover-open{position:fixed;inset:auto;transform:translateX(-100%)}' + ':host([data-filled][data-editable]:hover) .ctl,:host([data-reframe]) .ctl' + '  {opacity:1;pointer-events:auto}' + '.ctl button{appearance:none;border:0;border-radius:6px;padding:5px 10px;cursor:pointer;' + '  background:rgba(0,0,0,.65);color:#fff;font:11px/1 system-ui,-apple-system,sans-serif;' + '  backdrop-filter:blur(6px)}' + '.ctl button:hover{background:rgba(0,0,0,.8)}' + '.err{position:absolute;left:8px;bottom:8px;right:8px;color:#b3261e;font-size:11px;' + '  background:rgba(255,255,255,.85);padding:4px 6px;border-radius:5px;pointer-events:none}' +
  // Replacement in flight: after a src swap the browser keeps painting
  // the PREVIOUS image until the new one decodes, so a Replace would
  // flash the old photo and then pop. Hide the stale frame (visibility,
  // not display — _applyView geometry still applies) and spin until the
  // new image reports in (load/error clears data-swapping).
  ':host([data-swapping]) .frame img{visibility:hidden}' + '.loading{position:absolute;inset:0;display:none;align-items:center;' + '  justify-content:center;pointer-events:none}' + ':host([data-swapping]) .loading{display:flex}' + '.loading::after{content:"";width:22px;height:22px;border-radius:50%;' + '  border:2px solid rgba(127,127,127,.25);border-top-color:currentColor;' + '  animation:om-slot-spin .7s linear infinite}' + '@keyframes om-slot-spin{to{transform:rotate(360deg)}}' +
  // Reduced motion: the static two-tone ring still reads as "working".
  '@media (prefers-reduced-motion:reduce){.loading::after{animation:none}}' + '.credit{position:absolute;left:6px;bottom:6px;max-width:calc(100% - 12px);display:none;' + '  padding:3px 7px;border-radius:5px;background:rgba(0,0,0,.55);color:#fff;' + '  font:10px/1.2 system-ui,-apple-system,sans-serif;text-decoration:none;' + '  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;backdrop-filter:blur(6px)}' +
  // The credit is a SPAN holding one or two <a>s (Unsplash's prescribed
  // form links the photographer AND Unsplash) — anchors style inline so
  // the overlay reads as one line of text.
  '.credit a{color:inherit;text-decoration:none}' + '.credit a:hover,.credit a:focus-visible{text-decoration:underline}' + ':host([data-filled][data-credit]) .credit{display:block}' +
  // Exports must ship JUST the image — no hover controls, no credit chip
  // (the host marks <html data-om-exporting> for the capture window; the
  // page-level hide script can't reach shadow DOM, this rule can).
  ':host-context([data-om-exporting]) .ctl,' + ':host-context([data-om-exporting]) .credit{display:none !important}' +
  // Print must ship just the image too: the hover-gated controls can be
  // mid-hover when print() fires, and the credit chip is screen chrome —
  // the same rule the capture window gets, keyed on print media instead
  // of the host's data-om-exporting mark (the print path sets no mark).
  '@media print{.ctl,.credit{display:none !important}}' +
  // No export-window mask rules here on purpose: the export capture
  // releases the replacement mask by REMOVING data-swapping (the
  // shadow-root pass in pages/export/shared.ts HIDE_EXPORT_CHROME_SCRIPT)
  // — attribute removal works in every engine (:host-context is
  // Chromium-only), is scoped by construction to slots actually
  // mid-swap, and hides the spinner through the same gate. A masked img
  // would otherwise be silently dropped from PPTX decks (the capture
  // walk skips visibility:hidden imgs).
  // Attribution error tile: REPLACES the photo when an Unsplash src has
  // no credit attribute — rendering the photo uncredited is the terms
  // violation, so the photo must not appear at all.
  // Calm and neutral on purpose (review feedback): the tile informs the
  // user; the fix instructions are machine-facing (usage docblock, tool
  // description, and the turn-end scan's bounce copy name the attributes
  // for the agent).
  '.attr-error{position:absolute;inset:0;display:none;flex-direction:column;align-items:center;' + '  justify-content:center;gap:6px;text-align:center;padding:12px;box-sizing:border-box;' + '  background:#f2f1ef;color:#6e6c66;user-select:none;' + '  font:13px/1.45 system-ui,-apple-system,sans-serif}' + '.attr-error svg{opacity:.55}' + '.attr-error .cap{max-width:92%;font-weight:500;letter-spacing:.01em}' + ':host([data-attribution-error]) .attr-error{display:flex}' + ':host([data-attribution-error]) .ring{display:none}';
  const icon = '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' + 'stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">' + '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/>' + '<path d="m21 15-5-5L5 21"/></svg>';
  const warnIcon = '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' + 'stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">' + '<path d="m21.73 18-8-14a2 2 0 0 0-3.46 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/>' + '<path d="M12 9v4"/><path d="M12 17h.01"/></svg>';
  class ImageSlot extends HTMLElement {
    static get observedAttributes() {
      return ['shape', 'radius', 'mask', 'fit', 'placeholder', 'src', 'id', 'credit', 'credit-href'];
    }

    /** Duplicate-slide hook (called by deck-stage, see its
     *  _remintDuplicateIds): copy this id's stored image, if any, under a
     *  freshly minted key and return that key — so a duplicated slide's
     *  slot keeps its dropped photo instead of reverting to the
     *  placeholder. 'isFree' is the caller's uniqueness check (document
     *  ids); candidates must ALSO be unused in the sidecar, which can
     *  hold keys from other pages sharing the project root. (An EMPTY
     *  slot on another page leaves no sidecar entry, so its id is not
     *  detectable here — a minted key can collide with it and that slot
     *  would show this photo. Same blast radius as two pages reusing an
     *  id by hand, which the shared sidecar already permits.) Returns null
     *  when no id could be minted (caller strips the id, today's
     *  behavior). */
    static cloneSlot(fromId, isFree) {
      if (typeof fromId !== 'string' || !fromId) return null;
      // Pre-hydration the store can't veto candidates or source the copy
      // — degrade to the strip (today's behavior) rather than mint
      // against keys we can't see yet. Any rendered (= droppable) slot
      // means load() has already settled.
      if (!loaded) return null;
      const stem = fromId.replace(/-\d+$/, '') || fromId;
      for (let n = 2; n < 100; n++) {
        const toId = stem + '-' + n;
        if (toId === fromId) continue;
        if (slots[toId] !== undefined) {
          // Reuse a key holding this exact value (bytes AND crop) if no
          // live element here owns it — a duplicate op the host refused
          // after minting leaves such a key behind, and reusing keeps
          // refused retries from accumulating one orphaned copy per
          // attempt. Full equality (not just bytes) so a byte-identical
          // key another PAGE owns with its own crop is stepped past, not
          // adopted or rewritten. (Entries without .u never match.)
          const prev = getSlot(toId);
          const cur = getSlot(fromId);
          if (!(prev && cur && prev.u && prev.u === cur.u && prev.s === cur.s && prev.x === cur.x && prev.y === cur.y && (typeof isFree !== 'function' || isFree(toId)))) continue;
          return toId;
        }
        if (typeof isFree === 'function' && !isFree(toId)) continue;
        const v = getSlot(fromId);
        if (v) setSlot(toId, Object.assign({}, v));
        return toId;
      }
      return null;
    }
    constructor() {
      super();
      // clonable: rail thumbnails deep-clone slides and carry this shadow
      // along; reuse an already-cloned root so upgrade-after-clone works.
      // (Deliberately NOT serializable — a getHTML consumer would embed
      // multi-MB sidecar data-URLs into serialized page HTML.)
      const root = this.shadowRoot || this.attachShadow({
        mode: 'open',
        clonable: true
      });
      // .spill and .ctl sit OUTSIDE .frame so overflow:hidden + border-radius
      // on the frame (circle, pill, rounded) can't clip them.
      root.innerHTML = '<style>' + stylesheet + '</style>' + '<div class="frame" part="frame">' + '  <img part="image" alt="" draggable="false" style="display:none">' + '  <div class="empty" part="empty">' + icon + '    <div class="cap"></div>' + '    <div class="sub">or <u>browse files</u></div></div>' + '  <div class="attr-error" part="attribution-error">' + warnIcon + '    <div class="cap">This photo needs attribution</div></div>' + '  <div class="loading" part="loading"></div>' + '  <div class="ring" part="ring"></div>' + '</div>' +
      // Outside .frame, like .spill/.ctl — the frame's overflow:hidden +
      // border-radius/clip-path would cut the credit off on circle/pill/mask.
      // A SPAN, not an <a>: the prescribed Unsplash credit holds two links
      // (photographer + Unsplash), built per-render in _render().
      '<span class="credit" part="credit"></span>' + '<div class="spill" popover="manual" data-dc-edit-transparent>' + '  <img class="ghost" alt="" draggable="false">' + '  <div class="handle" data-c="nw"></div><div class="handle" data-c="ne"></div>' + '  <div class="handle" data-c="sw"></div><div class="handle" data-c="se"></div>' + '</div>' +
      // data-dc-edit-transparent: the DC editor's edit-mode picker lets
      // clicks through for chrome marked with it (EDIT_TRANSPARENT_SEL)
      // — without it, Replace/Edit clicks in Edit mode are swallowed by
      // element selection and the controls look dead.
      '<div class="ctl" popover="manual" data-dc-edit-transparent><button data-act="replace" title="Replace image">Replace</button>' + '  <button data-act="edit" title="Reframe image">Edit</button></div>' + '<input type="file" accept="' + ACCEPT.join(',') + '" hidden>';
      this._frame = root.querySelector('.frame');
      this._ring = root.querySelector('.ring');
      this._img = root.querySelector('.frame img');
      this._empty = root.querySelector('.empty');
      this._cap = root.querySelector('.cap');
      this._sub = root.querySelector('.sub');
      this._spill = root.querySelector('.spill');
      this._ctl = root.querySelector('.ctl');
      this._credit = root.querySelector('.credit');
      this._attrError = root.querySelector('.attr-error');
      // Credit clicks open the link, not browse/reframe.
      this._credit.addEventListener('click', e => e.stopPropagation());
      this._credit.addEventListener('dblclick', e => e.stopPropagation());
      this._ghost = root.querySelector('.ghost');
      this._err = null;
      this._input = root.querySelector('input');
      this._depth = 0;
      this._gen = 0;
      // Encode-in-flight marker (the owning _ingest generation): while set,
      // the same-src "nothing in flight" clear in _render must not fire —
      // the stored value still points at the OLD image until the encode
      // lands, so that clear would unmask the stale image mid-replace.
      this._swapGen = 0;
      // Render-owned swap in flight: set when _render assigns a new src,
      // cleared only by the img's own load/error (or the empty branch).
      // img.complete CANNOT stand in for this — setting src only QUEUES
      // the current-request swap (a microtask), so synchronously after an
      // assignment, complete still reports the OLD settled request. The
      // pick path does exactly that: the host sets src, credit, and
      // credit-href back-to-back in one task, and renders #2/#3 would
      // read the stale complete === true and drop the mask one render
      // after it was set.
      this._loadPending = false;
      // See _render's empty branch: a transient attribution-error wipe of a
      // showing image must make the follow-up render a replacement (spinner),
      // not a first fill (blank frame).
      this._hidShowing = false;
      this._view = {
        s: 1,
        x: 0,
        y: 0
      };
      this._subFn = () => this._render();
      // Shadow-DOM listeners live with the shadow DOM — bound once here so
      // disconnect/reconnect (e.g. React remount) doesn't stack handlers.
      this._empty.addEventListener('click', () => this._input.click());
      root.addEventListener('click', e => {
        const act = e.target && e.target.getAttribute && e.target.getAttribute('data-act');
        if (!act) return;
        // The hidden controls are opacity-0 but still tabbable — without
        // this gate a keyboard user could drive them on a read-only share
        // link (mirrors the dblclick handler's editable gate).
        if (!this.hasAttribute('data-editable')) return;
        if (act === 'replace') {
          this._exitReframe(true);
          // Host-owned picker (Unsplash modal; it also offers local import).
          this.dispatchEvent(new CustomEvent('image-slot:pick', {
            bubbles: true,
            composed: true,
            detail: {
              id: this.id || null
            }
          }));
        }
        if (act === 'edit') {
          if (!this._reframes()) return;
          if (this.hasAttribute('data-reframe')) this._exitReframe(true);else this._enterReframe();
        }
      });
      this._input.addEventListener('change', () => {
        const f = this._input.files && this._input.files[0];
        if (f) this._ingest(f);
        this._input.value = '';
      });
      // naturalWidth/Height aren't known until load — re-apply so the cover
      // baseline is computed from real dimensions, not the 100%×100% fallback.
      // load/error also release the replacement-in-flight mask (via the
      // single discipline in _releaseMask): the swap is only revealed once
      // the new image can actually paint (on error the frame shows its
      // background, same as a fresh slot with a broken src).
      this._img.addEventListener('load', () => {
        this._loadPending = false;
        this._releaseMask(true);
        this._applyView();
      });
      this._img.addEventListener('error', () => {
        this._loadPending = false;
        this._releaseMask(true);
      });
      // Gated only on editable — any filled slot can be repositioned/scaled,
      // regardless of fit. Share links (no writeFile) stay static.
      this.addEventListener('dblclick', e => {
        if (!this.hasAttribute('data-editable') || !this._reframes()) return;
        e.preventDefault();
        if (this.hasAttribute('data-reframe')) this._exitReframe(true);else this._enterReframe();
      });
      // Pan + resize both originate on the spill layer. A handle pointerdown
      // drives an aspect-locked resize anchored at the opposite corner; any
      // other pointerdown on the spill pans. Offsets are frame-% so a
      // reframed slot survives responsive resize / PPTX export.
      this._spill.addEventListener('pointerdown', e => {
        if (e.button !== 0 || !this.hasAttribute('data-reframe')) return;
        e.preventDefault();
        e.stopPropagation();
        this._spill.setPointerCapture(e.pointerId);
        const rect = this.getBoundingClientRect();
        const fw = rect.width || 1,
          fh = rect.height || 1;
        const corner = e.target.getAttribute && e.target.getAttribute('data-c');
        let move;
        if (corner) {
          // Resize about the OPPOSITE corner. Viewport-px throughout (rect
          // fw/fh, not clientWidth) so the math survives a transform:scale()
          // ancestor — deck_stage renders slides scaled-to-fit.
          const iw = this._img.naturalWidth || 1,
            ih = this._img.naturalHeight || 1;
          const contain = (this.getAttribute('fit') || 'cover').toLowerCase() === 'contain';
          const base = contain ? Math.min(fw / iw, fh / ih) : Math.max(fw / iw, fh / ih);
          const sx = corner.includes('e') ? 1 : -1;
          const sy = corner.includes('s') ? 1 : -1;
          const s0 = this._view.s;
          const w0 = iw * base * s0,
            h0 = ih * base * s0;
          const cx0 = (50 + this._view.x) / 100 * fw;
          const cy0 = (50 + this._view.y) / 100 * fh;
          const ox = cx0 - sx * w0 / 2,
            oy = cy0 - sy * h0 / 2;
          const diag0 = Math.hypot(w0, h0);
          const ux = sx * w0 / diag0,
            uy = sy * h0 / diag0;
          move = ev => {
            const proj = (ev.clientX - rect.left - ox) * ux + (ev.clientY - rect.top - oy) * uy;
            const s = clampS(s0 * proj / diag0);
            const d = diag0 * s / s0;
            this._view.s = s;
            this._view.x = (ox + ux * d / 2) / fw * 100 - 50;
            this._view.y = (oy + uy * d / 2) / fh * 100 - 50;
            this._clampView();
            this._applyView();
          };
        } else {
          this.setAttribute('data-panning', '');
          const start = {
            px: e.clientX,
            py: e.clientY,
            x: this._view.x,
            y: this._view.y
          };
          move = ev => {
            this._view.x = start.x + (ev.clientX - start.px) / fw * 100;
            this._view.y = start.y + (ev.clientY - start.py) / fh * 100;
            this._clampView();
            this._applyView();
          };
        }
        const up = () => {
          try {
            this._spill.releasePointerCapture(e.pointerId);
          } catch {}
          this._spill.removeEventListener('pointermove', move);
          this._spill.removeEventListener('pointerup', up);
          this._spill.removeEventListener('pointercancel', up);
          this.removeAttribute('data-panning');
          this._dragUp = null;
        };
        // Stashed so _exitReframe (Escape / outside-click mid-drag) can
        // tear the capture + listeners down synchronously.
        this._dragUp = up;
        this._spill.addEventListener('pointermove', move);
        this._spill.addEventListener('pointerup', up);
        this._spill.addEventListener('pointercancel', up);
      });
      // Wheel zoom stays available inside reframe mode as a trackpad nicety —
      // zooms toward the cursor (offset' = cursor·(1-k) + offset·k).
      this.addEventListener('wheel', e => {
        if (!this.hasAttribute('data-reframe')) return;
        e.preventDefault();
        const r = this.getBoundingClientRect();
        const cx = (e.clientX - r.left) / r.width * 100 - 50;
        const cy = (e.clientY - r.top) / r.height * 100 - 50;
        const prev = this._view.s;
        const next = clampS(prev * Math.pow(1.0015, -e.deltaY));
        if (next === prev) return;
        const k = next / prev;
        this._view.s = next;
        this._view.x = cx * (1 - k) + this._view.x * k;
        this._view.y = cy * (1 - k) + this._view.y * k;
        this._clampView();
        this._applyView();
      }, {
        passive: false
      });
    }
    connectedCallback() {
      // Warn once per page — an id-less slot works for the session but
      // cannot persist, and two id-less slots would share nothing.
      if (!this.id && !ImageSlot._warned) {
        ImageSlot._warned = true;
        console.warn('<image-slot> without an id will not persist its dropped image.');
      }
      this.addEventListener('dragenter', this);
      this.addEventListener('dragover', this);
      this.addEventListener('dragleave', this);
      this.addEventListener('drop', this);
      subs.add(this._subFn);
      // The host may inject window.omelette.writeFile AFTER the first render;
      // re-render on hover so the editable-gated controls reliably appear.
      this.addEventListener('pointerenter', this._subFn);
      // width%/height% in _applyView encode the frame aspect at call time —
      // a host resize (responsive grid, pane divider) would stretch the
      // image until the next _render. Re-render on size change: _render()
      // re-seeds _view from stored before clamp/apply, so a shrink→grow
      // cycle round-trips instead of ratcheting x/y toward the narrower
      // frame's clamp range.
      this._ro = new ResizeObserver(() => this._render());
      this._ro.observe(this);
      load();
      this._render();
    }
    disconnectedCallback() {
      subs.delete(this._subFn);
      this.removeEventListener('pointerenter', this._subFn);
      this.removeEventListener('dragenter', this);
      this.removeEventListener('dragover', this);
      this.removeEventListener('dragleave', this);
      this.removeEventListener('drop', this);
      if (this._ro) {
        this._ro.disconnect();
        this._ro = null;
      }
      // commit=false: a disconnect is not a user intent — committing here
      // would persist whatever half-finished drag a React remount or DOM
      // splice happened to interrupt. Deliberate exits commit on their own
      // paths (Escape/click-out/toggle), and unloads commit via pagehide.
      this._exitReframe(false);
    }
    _enterReframe() {
      if (this.hasAttribute('data-reframe')) return;
      this.setAttribute('data-reframe', '');
      this._signalReframe(true);
      // Best-effort commit when the document unloads mid-reframe (a host
      // navigation racing the enter signal, a manual reload, tab close):
      // the sidecar write rides the host bridge, which outlives this
      // document, so the crop survives even though the mode dies with the
      // DOM. Held on the instance so _exitReframe detaches exactly what
      // was attached.
      this._pagehide = () => {
        this._exitReframe(true);
        flushNow();
      };
      window.addEventListener('pagehide', this._pagehide);
      // Promote spill to the top layer, then keep it pinned over the frame:
      // scroll/resize cover the common cases, and a per-frame rect check
      // catches layout shifts that fire neither (an image above finishing
      // load, streamed DOM pushing the slot down, an ancestor transform
      // change) so the overlay can't detach from the frame.
      try {
        this._spill.showPopover();
      } catch {}
      // After the spill, so the controls stack above it in the top layer.
      try {
        this._ctl.showPopover();
      } catch {}
      this._reposition = () => {
        if (this.hasAttribute('data-reframe')) this._applyView();
      };
      window.addEventListener('scroll', this._reposition, true);
      window.addEventListener('resize', this._reposition);
      this._lastRect = '';
      this._watch = () => {
        if (!this.hasAttribute('data-reframe')) return;
        const r = this.getBoundingClientRect();
        const key = r.left + ',' + r.top + ',' + r.width + ',' + r.height;
        if (key !== this._lastRect) {
          this._lastRect = key;
          this._applyView();
        }
        this._watchId = requestAnimationFrame(this._watch);
      };
      this._watchId = requestAnimationFrame(this._watch);
      this._applyView();
      // Close on click outside (the spill handler stopPropagation()s so
      // in-image drags don't reach this) and on Escape. Listeners are held
      // on the instance so _exitReframe / disconnectedCallback can detach
      // exactly what was attached.
      this._outside = e => {
        if (e.composedPath && e.composedPath().includes(this)) return;
        this._exitReframe(true);
      };
      this._esc = e => {
        if (e.key === 'Escape') this._exitReframe(true);
      };
      document.addEventListener('pointerdown', this._outside, true);
      document.addEventListener('keydown', this._esc, true);
    }
    _exitReframe(commit) {
      if (!this.hasAttribute('data-reframe')) return;
      if (this._dragUp) this._dragUp();
      this.removeAttribute('data-reframe');
      this.removeAttribute('data-panning');
      if (this._outside) document.removeEventListener('pointerdown', this._outside, true);
      if (this._esc) document.removeEventListener('keydown', this._esc, true);
      this._outside = this._esc = null;
      if (this._reposition) {
        window.removeEventListener('scroll', this._reposition, true);
        window.removeEventListener('resize', this._reposition);
        this._reposition = null;
      }
      if (this._watchId) {
        cancelAnimationFrame(this._watchId);
        this._watchId = 0;
      }
      if (this._pagehide) {
        window.removeEventListener('pagehide', this._pagehide);
        this._pagehide = null;
      }
      try {
        this._spill.hidePopover();
      } catch {}
      try {
        this._ctl.hidePopover();
      } catch {}
      this._ctl.style.left = '';
      this._ctl.style.top = '';
      if (commit) this._commitView();
      this._signalReframe(false);
    }

    // Reframe state lives only in this DOM until commit, invisible to the
    // host's dirty signals — announce enter/exit so the host can hold
    // auto-reloads for exactly the gesture (the guest bundle forwards
    // image-slot:reframe to the host as imageSlotReframe). Dispatched on
    // the element (composed, so it escapes shadow roots) while connected;
    // a disconnected exit (disconnectedCallback) falls back to document so
    // the host still hears it.
    _signalReframe(active) {
      const target = this.isConnected ? this : document;
      target.dispatchEvent(new CustomEvent('image-slot:reframe', {
        bubbles: true,
        composed: true,
        detail: {
          active: active,
          id: this.id || null
        }
      }));
    }

    // Public: host's "Import from computer" calls this to run local browse.
    openFilePicker() {
      this._exitReframe(true);
      this._input.click();
    }

    // A src write is a newer intent for this slot's content — the host
    // pick path (setImageSlotImage) or an agent edit — so it must win
    // over any encode still in flight from an earlier drop: left live,
    // that encode lands later, passes _ingest's gen guard, and its
    // setSlot silently overwrites the pick (the stored value shadows
    // src in _render). Bumping _gen kills the encode before its own
    // _swapGen clear runs, so clear the dead claim here too — otherwise
    // _releaseMask (gated on !_swapGen) never fires and the pick's
    // spinner is stranded. src ONLY: the pick sets credit/credit-href
    // in the same task, and clearing _swapGen on those would let the
    // same-src branch unmask the old image mid-encode.
    attributeChangedCallback(name, oldVal, newVal) {
      if (name === 'src' && oldVal !== newVal) {
        this._gen++;
        this._swapGen = 0;
      }
      if (this.shadowRoot) this._render();
    }

    // handleEvent — one listener object for all four drag events keeps the
    // add/remove symmetric and the depth counter correct.
    handleEvent(e) {
      if (e.type === 'dragenter' || e.type === 'dragover') {
        // Without preventDefault the browser never fires 'drop'.
        e.preventDefault();
        e.stopPropagation();
        if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
        if (e.type === 'dragenter') this._depth++;
        this.setAttribute('data-over', '');
      } else if (e.type === 'dragleave') {
        // dragenter/leave fire for every descendant crossing — count depth
        // so hovering the icon inside the empty state doesn't flicker.
        if (--this._depth <= 0) {
          this._depth = 0;
          this.removeAttribute('data-over');
        }
      } else if (e.type === 'drop') {
        e.preventDefault();
        e.stopPropagation();
        this._depth = 0;
        this.removeAttribute('data-over');
        const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
        if (f) this._ingest(f);
      }
    }
    async _ingest(file) {
      this._setError(null);
      if (!file || ACCEPT.indexOf(file.type) < 0) {
        this._setError('Drop a PNG, JPEG, WebP, or AVIF image.');
        return;
      }
      // toDataUrl can take hundreds of ms on a large photo. A Clear or a
      // newer drop during that window would be clobbered when this await
      // resumes — bump + capture a generation so stale encodes bail.
      const gen = ++this._gen;
      // Replacing a shown image: surface the swap through the encode too,
      // not just the decode — otherwise the old photo sits there with no
      // feedback while the canvas re-encode runs. An empty slot keeps its
      // placeholder (no spinner) until the encode lands, as before.
      // _swapGen guards the mask against re-renders DURING the encode
      // (pointerenter, ResizeObserver, another slot's store write): the
      // stored value still resolves to the old image there, so _render's
      // same-src clear would otherwise unmask it mid-replace.
      if (this.hasAttribute('data-filled')) {
        this.setAttribute('data-swapping', '');
        this._swapGen = gen;
      }
      try {
        const w = this.clientWidth || this.offsetWidth || MAX_DIM;
        const url = await toDataUrl(file, w);
        if (gen !== this._gen) return;
        // Only exit reframe once the new image is in hand — a rejected type
        // or decode failure leaves the in-progress crop untouched.
        this._exitReframe(false);
        // Clear BEFORE setSlot: its synchronous re-render must see no
        // pending encode, so a byte-identical re-upload (same data URL, no
        // load event coming) still clears the mask via the complete branch.
        this._swapGen = 0;
        const val = {
          u: url,
          s: 1,
          x: 0,
          y: 0
        };
        setSlot(this.id || '', val);
        // Keep a session-local copy for id-less slots so the drop still
        // shows, even though it cannot persist.
        if (!this.id) {
          this._local = val;
          this._render();
        }
      } catch (err) {
        if (gen !== this._gen) return;
        this._swapGen = 0;
        // Reveal the kept old image — unless another replacement (a
        // remote pick's src swap) is still in flight, in which case the
        // mask stays until THAT image settles (its load/error releases).
        this._releaseMask();
        this._setError('Could not read that image.');
        console.warn('<image-slot> ingest failed:', err);
      }
    }
    _setError(msg) {
      if (this._err) {
        this._err.remove();
        this._err = null;
      }
      if (!msg) return;
      const d = document.createElement('div');
      d.className = 'err';
      d.textContent = msg;
      this.shadowRoot.appendChild(d);
      this._err = d;
      setTimeout(() => {
        if (this._err === d) {
          d.remove();
          this._err = null;
        }
      }, 3000);
    }

    // Reframing (pan/resize) is available on any filled slot — the user can
    // always reposition/scale. `fit` only sets the initial baseline (see
    // _geom): contain starts fully-visible, cover starts frame-filling.
    _reframes() {
      return this.hasAttribute('data-filled');
    }

    // The single release discipline for the replacement-in-flight mask
    // (data-swapping). The mask comes off only when BOTH hold:
    //  - no encode is pending (_swapGen) — mid-encode the stored value
    //    still resolves to the old image, so any reveal paints it;
    //  - the frame img has settled on its current src — an unsettled src
    //    means some replacement is still in flight (e.g. a remote pick),
    //    whoever started it, and revealing would paint the previous
    //    frame. The load/error listeners pass settled=true (the event IS
    //    the settlement signal, per spec complete is true by then);
    //    other callers rely on the complete flag (covers loaded AND
    //    failed).
    // Every release path funnels through here EXCEPT _render's empty
    // branch (the img is being cleared — nothing will ever settle).
    _releaseMask(settled) {
      if (!this._swapGen && !this._loadPending && (settled || this._img.complete)) {
        this.removeAttribute('data-swapping');
      }
    }

    // Baseline geometry, shared by clamp/apply/resize. `base` is the scale at
    // view-scale s=1: cover = fill the frame (overflow on the looser axis),
    // contain = fit fully inside (letterboxed). Zooming a contain image past
    // s where it overflows naturally becomes a crop. Null until the img has
    // loaded (naturalWidth is 0 before that) or when the slot has no layout
    // box — ResizeObserver fires with a 0×0 rect under display:none, and
    // clamping against a degenerate 1×1 frame would silently pull the stored
    // pan toward zero.
    _geom() {
      const iw = this._img.naturalWidth,
        ih = this._img.naturalHeight;
      const fw = this.clientWidth,
        fh = this.clientHeight;
      if (!iw || !ih || !fw || !fh) return null;
      const contain = (this.getAttribute('fit') || 'cover').toLowerCase() === 'contain';
      const base = contain ? Math.min(fw / iw, fh / ih) : Math.max(fw / iw, fh / ih);
      return {
        iw,
        ih,
        fw,
        fh,
        base
      };
    }
    _clampView() {
      // Pan range on each axis is half the overflow past the frame edge.
      const g = this._geom();
      if (!g) return;
      const mx = Math.max(0, (g.iw * g.base * this._view.s / g.fw - 1) * 50);
      const my = Math.max(0, (g.ih * g.base * this._view.s / g.fh - 1) * 50);
      this._view.x = Math.max(-mx, Math.min(mx, this._view.x));
      this._view.y = Math.max(-my, Math.min(my, this._view.y));
    }
    _applyView() {
      const g = this._geom();
      // Top-layer controls: pin to the frame's top-right in viewport px
      // (the same 8px inset as the in-frame layout; unscaled — top-layer UI
      // reads as chrome, not page content). BEFORE the geometry branch:
      // placement needs only the frame rect, and a not-yet-loaded or broken
      // src must not leave the promoted strip floating unpositioned. Gated
      // on the popover actually being open: without the Popover API,
      // showPopover() threw (swallowed in _enterReframe), .ctl stays in
      // its in-frame absolute layout, and viewport-px coordinates would
      // shove it off-frame — and matches(':popover-open') itself throws
      // there (unknown pseudo-class), hence the try/catch.
      if (this.hasAttribute('data-reframe')) {
        let onTop = false;
        try {
          onTop = this._ctl.matches(':popover-open');
        } catch {}
        if (onTop) {
          const r = this.getBoundingClientRect();
          this._ctl.style.left = r.right - 8 + 'px';
          this._ctl.style.top = r.top + 8 + 'px';
        }
      }
      if (!g) {
        // Dimensions not known yet (before img load) — centered fit so there
        // is no flash of an unpositioned image before the geometry lands.
        const contain = (this.getAttribute('fit') || 'cover').toLowerCase() === 'contain';
        this._img.style.width = '100%';
        this._img.style.height = '100%';
        this._img.style.left = '50%';
        this._img.style.top = '50%';
        this._img.style.objectFit = contain ? 'contain' : 'cover';
        return;
      }
      // Baseline (cover-fill or contain-fit) × view scale. Width/height and
      // left/top are all frame-% — depends only on the frame aspect ratio, so
      // a responsive resize keeps the same crop. The spill layer mirrors the
      // same box so its corners = image corners.
      const k = g.base * this._view.s;
      const w = g.iw * k / g.fw * 100 + '%';
      const h = g.ih * k / g.fh * 100 + '%';
      const l = 50 + this._view.x + '%';
      const t = 50 + this._view.y + '%';
      this._img.style.width = w;
      this._img.style.height = h;
      this._img.style.left = l;
      this._img.style.top = t;
      this._img.style.objectFit = '';
      if (this.hasAttribute('data-reframe')) {
        // Top-layer spill: position in viewport px over the frame. The top
        // layer escapes ancestor transforms entirely, so EVERY term must be
        // in viewport units: getBoundingClientRect gives the frame's scaled
        // origin AND size, and the rect/layout ratio rescales the ghost —
        // sizing from layout px alone renders it 1/scale too large under a
        // scaled deck slide. Inner ghost + handles stay box-relative.
        const r = this.getBoundingClientRect();
        const sx = g.fw ? r.width / g.fw : 1;
        const sy = g.fh ? r.height / g.fh : 1;
        this._spill.style.width = g.iw * k * sx + 'px';
        this._spill.style.height = g.ih * k * sy + 'px';
        this._spill.style.left = r.left + (50 + this._view.x) / 100 * r.width + 'px';
        this._spill.style.top = r.top + (50 + this._view.y) / 100 * r.height + 'px';
      }
    }
    _commitView() {
      const v = {
        s: this._view.s,
        x: this._view.x,
        y: this._view.y
      };
      if (this._userUrl) v.u = this._userUrl;
      // Framing-only (no u) persists too so an author-src slot remembers its
      // crop; clearing the sidecar still falls through to src=.
      if (this.id) setSlot(this.id, v);else {
        this._local = v;
      }
    }
    _render() {
      // Shape / mask. Presets use border-radius so the dashed ring can
      // follow the rounded outline; clip-path is only applied for an
      // explicit `mask` (the ring is hidden there since a rectangle
      // dashed border chopped by an arbitrary polygon looks broken).
      const mask = this.getAttribute('mask');
      const shape = (this.getAttribute('shape') || 'rounded').toLowerCase();
      let radius = '';
      if (shape === 'circle') radius = '50%';else if (shape === 'pill') radius = '9999px';else if (shape === 'rounded') {
        const n = parseFloat(this.getAttribute('radius'));
        radius = (Number.isFinite(n) ? n : 12) + 'px';
      }
      this._frame.style.borderRadius = mask ? '' : radius;
      this._frame.style.clipPath = mask || '';
      this._ring.style.borderRadius = mask ? '' : radius;
      this._ring.style.display = mask ? 'none' : '';

      // Controls and reframe entry gate on this so share links stay read-only.
      const editable = !!(window.omelette && window.omelette.writeFile);
      this.toggleAttribute('data-editable', editable);
      this._sub.style.display = editable ? '' : 'none';

      // Content. The sidecar is also writable by the agent's write_file
      // tool, so its value isn't guaranteed canvas-originated — only accept
      // data:image/ URLs from it. The `src` attribute is author-controlled
      // (Claude wrote it into the HTML) so it passes through unchanged.
      let stored = this.id ? getSlot(this.id) : this._local;
      if (stored && stored.u && !/^data:image\//i.test(stored.u)) stored = null;
      const srcAttr = this.getAttribute('src') || '';
      this._userUrl = stored && stored.u || null;
      const url = this._userUrl || srcAttr;
      // Don't clobber an in-flight reframe with a store-triggered re-render.
      if (!this.hasAttribute('data-reframe')) {
        this._view = {
          s: stored && Number.isFinite(stored.s) ? clampS(stored.s) : 1,
          x: stored && Number.isFinite(stored.x) ? stored.x : 0,
          y: stored && Number.isFinite(stored.y) ? stored.y : 0
        };
      }
      this._cap.textContent = this.getAttribute('placeholder') || 'Drop an image';
      // Toggle via style.display — the [hidden] attribute alone loses to
      // the display:flex / display:block rules in the stylesheet above.
      // An Unsplash src with no credit attribute must NOT render — showing
      // the photo uncredited is the Unsplash-terms violation itself. The
      // error tile replaces the photo until the credit is written. A
      // user-dropped image is the user's own content and always renders.
      // Trimmed: credit is agent/user-editable content, and a whitespace-
      // only value must count as missing — otherwise it would suppress the
      // error tile AND render an empty credit box (no text, no links),
      // exactly the unattributed state this gate exists to prevent.
      const credit = (this.getAttribute('credit') || '').trim();
      const attrError = !!(!credit && !this._userUrl && srcAttr && isUnsplashHost(srcAttr));
      this.toggleAttribute('data-attribution-error', attrError);
      if (url && !attrError) {
        const prev = this._img.getAttribute('src');
        if (prev !== url) {
          // Replacing an already-shown image: mark the swap BEFORE setting
          // src so the stale frame is never revealed (see the data-swapping
          // stylesheet rules). First fill (prev empty) keeps the existing
          // placeholder-until-load behavior — no spinner. _hidShowing
          // covers the pick path's transient attribution-error wipe: prev
          // is gone, but an image WAS showing, so this is a replacement.
          if (prev || this._hidShowing) this.setAttribute('data-swapping', '');
          // Mark the swap BEFORE assigning src: complete keeps reporting
          // the old settled request until the browser's
          // update-the-image-data microtask runs, so same-task re-renders
          // (the pick path's credit/credit-href setAttributes) need this
          // flag, not complete, to know a load is in flight.
          this._loadPending = true;
          this._img.src = url;
          this._ghost.src = url;
        } else {
          // Same-src re-render — release if settled, so an ingest-set
          // spinner can't stick after a byte-identical re-upload (same
          // data URL, no further load event ever fires).
          this._releaseMask();
        }
        this._hidShowing = false;
        this._img.style.display = 'block';
        this._empty.style.display = 'none';
        this.setAttribute('data-filled', '');
        this._clampView();
        this._applyView();
      } else {
        this.removeAttribute('data-swapping');
        // The src is being removed — no load/error will ever fire for it.
        this._loadPending = false;
        // A transient attribution-error wipe of a showing image happens on
        // the pick path: the host sets src one setAttribute before credit,
        // so render N hides the old image (attrError) and render N+1
        // restores a URL. Remember the wipe so that restore renders as a
        // replacement (spinner), not a first fill (blank frame).
        this._hidShowing = attrError && !!this._img.getAttribute('src');
        this._img.style.display = 'none';
        this._img.removeAttribute('src');
        this._ghost.removeAttribute('src');
        // The error tile owns the blocked-photo state; .empty stays for
        // the genuinely-empty slot.
        this._empty.style.display = attrError ? 'none' : 'flex';
        this.removeAttribute('data-filled');
      }

      // Credit belongs to the author src, so a user drop hides it.
      // textContent + the http(s)-only funnel keep external strings inert.
      const showCredit = !!(url && credit && !this._userUrl && !attrError);
      this._credit.textContent = '';
      if (showCredit) {
        // Validate once (resolved against the document, http(s) only),
        // then append the terms-required utm referral params to links
        // that point back at unsplash.com.
        let href = '';
        const rawHref = this.getAttribute('credit-href') || '';
        if (rawHref) {
          try {
            const u = new URL(rawHref, document.baseURI);
            if (u.protocol === 'http:' || u.protocol === 'https:') {
              href = withReferral(u.href);
            }
          } catch {}
        }
        const mkLink = (text, linkHref) => {
          const a = document.createElement('a');
          a.setAttribute('target', '_blank');
          a.setAttribute('rel', 'noopener noreferrer');
          a.setAttribute('href', linkHref);
          a.textContent = text;
          return a;
        };
        // Unsplash's prescribed credit is TWO links — the photographer's
        // name to their profile (credit-href) and 'Unsplash' to the
        // homepage. Render that split whenever the text has the canonical
        // shape; other text keeps the legacy single-link rendering.
        const m = /^Photo by (.+) on Unsplash$/.exec(credit);
        if (m) {
          this._credit.appendChild(document.createTextNode('Photo by '));
          this._credit.appendChild(href ? mkLink(m[1], href) : document.createTextNode(m[1]));
          this._credit.appendChild(document.createTextNode(' on '));
          this._credit.appendChild(mkLink('Unsplash', UNSPLASH_HOMEPAGE_HREF));
        } else if (href) {
          this._credit.appendChild(mkLink(credit, href));
        } else {
          this._credit.textContent = credit;
        }
      }
      this.toggleAttribute('data-credit', showCredit);
    }
  }
  if (!customElements.get('image-slot')) {
    customElements.define('image-slot', ImageSlot);
  }
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/image-slot.js", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.DestinationCard = __ds_scope.DestinationCard;

__ds_ns.ListingCard = __ds_scope.ListingCard;

__ds_ns.NewsletterCard = __ds_scope.NewsletterCard;

__ds_ns.Accordion = __ds_scope.Accordion;

__ds_ns.Eyebrow = __ds_scope.Eyebrow;

__ds_ns.Location = __ds_scope.Location;

__ds_ns.LogoStrip = __ds_scope.LogoStrip;

__ds_ns.Rating = __ds_scope.Rating;

__ds_ns.SectionHeader = __ds_scope.SectionHeader;

__ds_ns.Testimonial = __ds_scope.Testimonial;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.Media = __ds_scope.Media;

__ds_ns.EmailField = __ds_scope.EmailField;

__ds_ns.SearchBar = __ds_scope.SearchBar;

__ds_ns.CarouselControls = __ds_scope.CarouselControls;

__ds_ns.NavBar = __ds_scope.NavBar;

})();
