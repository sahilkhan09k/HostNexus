Rounded image frame with cover-fit; shows a neutral placeholder until HostNexus imagery is supplied.
```jsx
<Media src="assets/images/villa.jpg" height={240}/>
<Media label="Hero photo"/>
```
