import React from 'react';
export function Media({src,alt='',children,radius='var(--radius-lg)',height='100%',label,style}){
  return <div style={{position:'relative',overflow:'hidden',borderRadius:radius,height,background:'var(--ink-100)',...style}}>
    {src?<img src={src} alt={alt} style={{position:'absolute',inset:0,width:'100%',height:'100%',objectFit:'cover'}}/>:children?children:
      <div style={{position:'absolute',inset:0,display:'grid',placeItems:'center',font:'500 11px var(--font-sans)',color:'var(--ink-400)',letterSpacing:'.02em'}}>{label||'Image'}</div>}
  </div>;
}
