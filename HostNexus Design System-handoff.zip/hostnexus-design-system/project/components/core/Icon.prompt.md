Line icon (Lucide paths, 1.5px stroke) used inside every HostNexus control; use whenever a glyph is needed.
```jsx
<Icon name="arrow-up-right" size={16}/>
<Icon name="star" fill="var(--star)" color="var(--star)" size={12}/>
```
Names: arrow-up-right, arrow-right, chevron-left/right/up/down, map-pin, star, search, shield-check, menu, x, mail.
