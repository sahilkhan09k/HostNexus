export interface MediaProps{
  /** Image URL. When absent, children render (e.g. an <image-slot>), else a neutral placeholder. */
  src?: string; alt?: string; children?: React.ReactNode;
  radius?: string|number; height?: string|number; label?: string; style?: React.CSSProperties;
}
export declare function Media(props: MediaProps): JSX.Element;
