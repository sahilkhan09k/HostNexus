export type IconName='arrow-up-right'|'arrow-right'|'chevron-left'|'chevron-right'|'chevron-down'|'chevron-up'|'map-pin'|'star'|'search'|'shield-check'|'menu'|'x'|'mail';
export interface IconProps{ name: IconName; size?: number; strokeWidth?: number; color?: string; fill?: string; style?: React.CSSProperties; }
export declare function Icon(props: IconProps): JSX.Element;
