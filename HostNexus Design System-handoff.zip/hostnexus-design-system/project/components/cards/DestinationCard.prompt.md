Photo tile with bottom gradient scrim and white text; use in featured-destination bento grids.
```jsx
<DestinationCard size="lg" height={420} title="Vista Grand Suites" location="Phuket, Thailand" rating={4.9} image={src}/>
```
Image zooms 4% on hover.
