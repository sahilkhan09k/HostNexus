export interface ListingCardProps{
  title: React.ReactNode;
  /** Pre-formatted, e.g. "$150,000" */
  price?: React.ReactNode;
  location?: React.ReactNode;
  image?: string;
  media?: React.ReactNode;
  imageHeight?: number;
  width?: number|string;
  onClick?: () => void;
  style?: React.CSSProperties;
}
export declare function ListingCard(props: ListingCardProps): JSX.Element;
