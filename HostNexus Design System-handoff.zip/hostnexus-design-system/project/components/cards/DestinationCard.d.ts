/**
 * Full-bleed photo card with bottom scrim, title, location, rating and glass arrow.
 * @startingPoint section="Cards" subtitle="Photo destination card" viewport="700x340"
 */
export interface DestinationCardProps{
  title: React.ReactNode;
  location?: React.ReactNode;
  rating?: number;
  /** Image URL (supplied by HostNexus) */
  image?: string;
  /** Alternative to image — e.g. <image-slot> */
  media?: React.ReactNode;
  height?: number|string;
  /** lg = feature tile (bigger title) */
  size?: 'md'|'lg';
  onClick?: () => void;
  style?: React.CSSProperties;
}
export declare function DestinationCard(props: DestinationCardProps): JSX.Element;
