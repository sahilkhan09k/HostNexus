import React from 'react';
import { Media } from '../core/Media.jsx';
import { Location } from '../content/Location.jsx';
import { Rating } from '../content/Rating.jsx';
import { IconButton } from '../actions/IconButton.jsx';
export function DestinationCard({title,location,rating,image,media,height=300,size='md',onClick,style}){
  const [h,setH]=React.useState(false);const lg=size==='lg';
  return <div onClick={onClick} onMouseEnter={()=>setH(true)} onMouseLeave={()=>setH(false)} style={{position:'relative',height,borderRadius:'var(--radius-lg)',overflow:'hidden',cursor:onClick?'pointer':'default',...style}}>
    <div style={{position:'absolute',inset:0,transform:h?'scale(1.04)':'scale(1)',transition:'transform var(--dur-slow) var(--ease-out)'}}><Media src={image} radius={0} label={title}>{media}</Media></div>
    <div style={{position:'absolute',inset:0,background:'var(--overlay-photo)',pointerEvents:'none'}}></div>
    <div style={{position:'absolute',left:lg?24:18,right:lg?24:18,bottom:lg?22:16,display:'flex',alignItems:'flex-end',justifyContent:'space-between',gap:12}}>
      <div style={{display:'flex',flexDirection:'column',gap:8}}>
        <div style={{font:`400 ${lg?28:20}px/1.1 var(--font-sans)`,letterSpacing:'var(--tracking-heading)',color:'var(--white)'}}>{title}</div>
        <div style={{display:'flex',gap:12,flexWrap:'wrap'}}>{location&&<Location tone="light">{location}</Location>}{rating!=null&&<Rating value={rating} tone="light"/>}</div>
      </div>
      <IconButton icon="arrow-up-right" variant="glass" size={lg?36:30} label="Open"/>
    </div>
  </div>;
}
