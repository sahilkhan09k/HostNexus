export interface NewsletterCardProps{ message?: React.ReactNode; placeholder?: string; onSubmit?: (email: string) => void; width?: number|string; style?: React.CSSProperties; }
export declare function NewsletterCard(props: NewsletterCardProps): JSX.Element;
