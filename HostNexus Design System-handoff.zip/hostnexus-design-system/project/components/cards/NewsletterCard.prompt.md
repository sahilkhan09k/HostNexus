Dark rounded card with centred invitation copy and an email pill; centrepiece of the photo-rail community section.
```jsx
<NewsletterCard onSubmit={subscribe}/>
```
