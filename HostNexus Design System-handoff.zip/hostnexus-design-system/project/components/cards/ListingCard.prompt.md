Property listing: rounded image above a name/price row and location meta; use in horizontal carousels.
```jsx
<ListingCard title="City Center Apartments" price="$150,000" location="New York, USA" image={src}/>
```
