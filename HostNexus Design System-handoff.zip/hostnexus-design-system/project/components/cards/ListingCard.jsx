import React from 'react';
import { Media } from '../core/Media.jsx';
import { Location } from '../content/Location.jsx';
export function ListingCard({title,price,location,image,media,imageHeight=220,width,onClick,style}){
  const [h,setH]=React.useState(false);
  return <div onClick={onClick} onMouseEnter={()=>setH(true)} onMouseLeave={()=>setH(false)} style={{display:'flex',flexDirection:'column',gap:12,width,cursor:onClick?'pointer':'default',...style}}>
    <div style={{borderRadius:'var(--radius-md)',overflow:'hidden'}}><div style={{transform:h?'scale(1.04)':'none',transition:'transform var(--dur-slow) var(--ease-out)'}}><Media src={image} height={imageHeight} radius={0} label={title}>{media}</Media></div></div>
    <div style={{display:'flex',flexDirection:'column',gap:6}}>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'baseline',gap:12}}>
        <span style={{font:'400 15px var(--font-sans)',color:'var(--text-strong)'}}>{title}</span>
        {price&&<span style={{font:'500 17px var(--font-sans)',color:'var(--text-strong)',letterSpacing:'-0.01em'}}>{price}</span>}
      </div>
      {location&&<Location>{location}</Location>}
    </div>
  </div>;
}
