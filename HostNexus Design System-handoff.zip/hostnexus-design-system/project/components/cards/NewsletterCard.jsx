import React from 'react';
import { EmailField } from '../forms/EmailField.jsx';
export function NewsletterCard({message='Join our community of travelers and experience unforgettable stays.',placeholder='support@hostnexus.com',onSubmit,width=300,style}){
  return <div style={{width,maxWidth:'100%',boxSizing:'border-box',background:'var(--surface-card-dark)',borderRadius:'var(--radius-lg)',padding:'28px 20px 20px',display:'flex',flexDirection:'column',gap:28,boxShadow:'var(--shadow-lg)',...style}}>
    <p style={{margin:0,textAlign:'center',font:'400 16px/1.5 var(--font-sans)',color:'var(--white)',textWrap:'balance'}}>{message}</p>
    <EmailField placeholder={placeholder} onSubmit={onSubmit}/>
  </div>;
}
