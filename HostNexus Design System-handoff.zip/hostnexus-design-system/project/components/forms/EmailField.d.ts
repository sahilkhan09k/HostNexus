export interface EmailFieldProps{
  placeholder?: string;
  defaultValue?: string;
  tone?: 'dark'|'light';
  onSubmit?: (email: string) => void;
  style?: React.CSSProperties;
}
export declare function EmailField(props: EmailFieldProps): JSX.Element;
