Pill email input with circular arrow submit; use for newsletter / community sign-up.
```jsx
<EmailField placeholder="support@hostnexus.com" onSubmit={subscribe}/>
```
