Hotel search pill with inline ember "Search" button; use in the hero over photography (tone="glass") or on light pages.
```jsx
<SearchBar onSubmit={q=>go(q)}/>
<SearchBar tone="light" width={420}/>
```
