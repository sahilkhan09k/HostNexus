/**
 * Pill search field with ember submit — sits bottom-right of the hero.
 * @startingPoint section="Forms" subtitle="Glass hero search pill" viewport="700x260"
 */
export interface SearchBarProps{
  placeholder?: string;
  buttonLabel?: string;
  /** glass = translucent dark over photos; light = white on page */
  tone?: 'glass'|'light';
  value?: string;
  width?: number|string;
  onChange?: (v: string) => void;
  onSubmit?: (v: string) => void;
  style?: React.CSSProperties;
}
export declare function SearchBar(props: SearchBarProps): JSX.Element;
