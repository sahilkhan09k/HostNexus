import React from 'react';
import { Icon } from '../core/Icon.jsx';
export function EmailField({placeholder='you@email.com',defaultValue='',tone='dark',onSubmit,style}){
  const [v,setV]=React.useState(defaultValue);const dark=tone==='dark';
  return <form onSubmit={e=>{e.preventDefault();onSubmit&&onSubmit(v)}} style={{display:'flex',alignItems:'center',height:48,padding:4,paddingLeft:18,boxSizing:'border-box',borderRadius:'var(--radius-pill)',
      background:dark?'var(--ink-700)':'var(--white)',border:`1px solid ${dark?'rgba(255,255,255,.14)':'var(--border-default)'}`,...style}}>
    <input type="email" value={v} placeholder={placeholder} onChange={e=>setV(e.target.value)} style={{flex:1,minWidth:0,border:0,outline:0,background:'transparent',font:'400 14px var(--font-sans)',color:dark?'var(--white)':'var(--text-strong)'}}/>
    <button type="submit" aria-label="Subscribe" style={{width:40,height:40,borderRadius:'50%',border:0,background:dark?'var(--white)':'var(--accent)',color:dark?'var(--ink-900)':'var(--white)',display:'grid',placeItems:'center',cursor:'pointer'}}><Icon name="arrow-up-right" size={18}/></button>
  </form>;
}
