import React from 'react';
export function SearchBar({placeholder='Search hotel',buttonLabel='Search',tone='glass',value,onChange,onSubmit,width=300,style}){
  const [v,setV]=React.useState(value??'');
  const glass=tone==='glass';
  return <form onSubmit={e=>{e.preventDefault();onSubmit&&onSubmit(v)}} style={{display:'flex',alignItems:'center',width,maxWidth:'100%',height:44,padding:4,paddingLeft:18,boxSizing:'border-box',borderRadius:'var(--radius-pill)',
      background:glass?'var(--glass-dark)':'var(--white)',border:`1px solid ${glass?'var(--border-inverse)':'var(--border-default)'}`,backdropFilter:glass?'var(--blur-glass)':undefined,...style}}>
    <input value={v} placeholder={placeholder} onChange={e=>{setV(e.target.value);onChange&&onChange(e.target.value)}}
      style={{flex:1,minWidth:0,border:0,outline:0,background:'transparent',font:'400 13px var(--font-sans)',color:glass?'var(--white)':'var(--text-strong)'}}/>
    <button type="submit" style={{height:34,padding:'0 18px',border:0,borderRadius:'var(--radius-pill)',background:'var(--accent)',color:'var(--white)',font:'500 13px var(--font-sans)',cursor:'pointer'}}>{buttonLabel}</button>
  </form>;
}
