Prev (outline) / next (ember) circle pair for carousels and testimonial sliders.
```jsx
<CarouselControls onPrev={prev} onNext={next}/>
```
