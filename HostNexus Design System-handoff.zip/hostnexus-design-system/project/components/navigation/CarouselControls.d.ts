export interface CarouselControlsProps{ onPrev?: () => void; onNext?: () => void; canPrev?: boolean; canNext?: boolean; size?: number; style?: React.CSSProperties; }
export declare function CarouselControls(props: CarouselControlsProps): JSX.Element;
