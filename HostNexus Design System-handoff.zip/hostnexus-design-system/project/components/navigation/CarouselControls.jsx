import React from 'react';
import { IconButton } from '../actions/IconButton.jsx';
export function CarouselControls({onPrev,onNext,canPrev=true,canNext=true,size=36,style}){
  return <div style={{display:'flex',gap:10,...style}}>
    <IconButton icon="chevron-left" variant="outline" size={size} label="Previous" onClick={onPrev} disabled={!canPrev}/>
    <IconButton icon="chevron-right" variant="accent" size={size} label="Next" onClick={onNext} disabled={!canNext}/>
  </div>;
}
