Transparent top navigation placed over the hero photo; text links + small ember Sign In pill, hairline rule below.
```jsx
<NavBar onCta={()=>setView('signin')}/>
<NavBar tone="dark" brand="HostNexus"/>
```
