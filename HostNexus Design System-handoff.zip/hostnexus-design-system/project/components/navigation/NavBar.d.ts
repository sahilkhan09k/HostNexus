/**
 * Minimal top nav — text links left, ember pill right, hairline underneath.
 * @startingPoint section="Navigation" subtitle="Transparent hero nav" viewport="1100x160"
 */
export interface NavBarProps{
  links?: string[];
  active?: string;
  ctaLabel?: string;
  onCta?: () => void;
  onNavigate?: (link: string) => void;
  /** light = white text over photography; dark = ink text on page */
  tone?: 'light'|'dark';
  /** Optional wordmark text — source nav omits it (brand lives in the giant hero wordmark) */
  brand?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function NavBar(props: NavBarProps): JSX.Element;
