import React from 'react';
import { Button } from '../actions/Button.jsx';
export function NavBar({links=['Explore Hotels','Deals & Offers','Destinations'],active,ctaLabel='Sign In',onCta,onNavigate,tone='light',brand,style}){
  const fg=tone==='light'?'var(--white)':'var(--text-strong)';
  return <nav style={{display:'flex',alignItems:'center',justifyContent:'space-between',gap:24,padding:'20px 0',borderBottom:`1px solid ${tone==='light'?'var(--border-inverse)':'var(--border-subtle)'}`,...style}}>
    <div style={{display:'flex',alignItems:'center',gap:32}}>
      {brand&&<span style={{font:'500 18px var(--font-sans)',letterSpacing:'-0.03em',color:fg}}>{brand}</span>}
      <div style={{display:'flex',gap:28}}>{links.map(l=><a key={l} href="#" onClick={e=>{e.preventDefault();onNavigate&&onNavigate(l)}}
        style={{font:`${active===l?500:400} 13px var(--font-sans)`,color:fg,opacity:active&&active!==l?.75:1,textDecoration:'none',whiteSpace:'nowrap'}}>{l}</a>)}</div>
    </div>
    <Button size="sm" onClick={onCta}>{ctaLabel}</Button>
  </nav>;
}
