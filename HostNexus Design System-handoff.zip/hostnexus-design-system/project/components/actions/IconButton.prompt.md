Circular icon-only button; use for carousel arrows, card corner arrows, submit chips.
```jsx
<IconButton icon="chevron-right" variant="accent" label="Next"/>
<IconButton icon="arrow-up-right" variant="glass" size={32}/>
```
Variants: accent · outline · light · dark · glass (over photos).
