import React from 'react';
import { Icon } from '../core/Icon.jsx';
const SZ={sm:{h:36,px:16,fs:13,chip:26},md:{h:44,px:20,fs:14,chip:32},lg:{h:52,px:28,fs:15,chip:38}};
const V={
  primary:{bg:'var(--accent)',fg:'var(--on-accent)',bd:'transparent',chipBg:'var(--white)',chipFg:'var(--ink-900)',hover:'var(--accent-hover)'},
  outline:{bg:'transparent',fg:'var(--text-strong)',bd:'var(--border-strong)',chipBg:'var(--accent)',chipFg:'var(--white)',hover:'var(--surface-muted)'},
  dark:{bg:'var(--ink-900)',fg:'var(--white)',bd:'transparent',chipBg:'var(--accent)',chipFg:'var(--white)',hover:'var(--ink-700)'},
  light:{bg:'var(--white)',fg:'var(--ink-900)',bd:'transparent',chipBg:'var(--accent)',chipFg:'var(--white)',hover:'var(--ink-50)'},
  ghost:{bg:'transparent',fg:'currentColor',bd:'transparent',chipBg:'var(--accent)',chipFg:'var(--white)',hover:'rgba(127,127,127,.12)'}
};
export function Button({children,variant='primary',size='md',arrow=false,disabled=false,fullWidth=false,onClick,type='button',style}){
  const s=SZ[size]||SZ.md,v=V[variant]||V.primary;
  const [h,setH]=React.useState(false),[p,setP]=React.useState(false);
  return <button type={type} disabled={disabled} onClick={onClick}
    onMouseEnter={()=>setH(true)} onMouseLeave={()=>{setH(false);setP(false)}} onMouseDown={()=>setP(true)} onMouseUp={()=>setP(false)}
    style={{display:fullWidth?'flex':'inline-flex',width:fullWidth?'100%':undefined,alignItems:'center',justifyContent:'center',gap:12,height:s.h,
      padding:arrow?`0 ${(s.h-s.chip)/2}px 0 ${s.px}px`:`0 ${s.px}px`,borderRadius:'var(--radius-pill)',border:`1px solid ${v.bd}`,
      background:h&&!disabled?v.hover:v.bg,color:v.fg,font:`500 ${s.fs}px/1 var(--font-sans)`,letterSpacing:'-0.01em',cursor:disabled?'not-allowed':'pointer',
      opacity:disabled?.45:1,transform:p&&!disabled?'scale(.97)':'none',transition:'background var(--dur-fast) var(--ease-out),transform var(--dur-fast) var(--ease-out)',whiteSpace:'nowrap',...style}}>
    <span>{children}</span>
    {arrow&&<span style={{width:s.chip,height:s.chip,borderRadius:'50%',background:v.chipBg,color:v.chipFg,display:'grid',placeItems:'center',
      boxShadow:variant==='primary'?'inset 0 0 0 1px var(--ember-600)':'none',transform:h&&!disabled?'rotate(45deg)':'none',transition:'transform var(--dur-base) var(--ease-out)'}}>
      <Icon name="arrow-up-right" size={Math.round(s.chip*0.5)}/></span>}
  </button>;
}
