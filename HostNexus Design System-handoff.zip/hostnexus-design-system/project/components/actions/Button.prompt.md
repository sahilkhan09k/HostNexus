Pill-shaped action; use for every CTA. Add `arrow` for the signature arrow-chip style (Learn More, Get Started, Explore Now).
```jsx
<Button arrow>Get Started</Button>
<Button variant="outline" arrow>Learn More</Button>
<Button size="sm">Sign In</Button>
```
Variants: primary · outline · dark · light · ghost. Sizes sm 36 / md 44 / lg 52. Hover darkens + rotates chip; press scales to .97.
