/**
 * Pill button. Optional trailing arrow chip (circle) — the signature HostNexus CTA.
 * @startingPoint section="Actions" subtitle="Pill CTA with arrow chip" viewport="700x300"
 */
export interface ButtonProps{
  children?: React.ReactNode;
  /** primary = ember fill; outline = grey border; dark/light for photo or dark sections */
  variant?: 'primary'|'outline'|'dark'|'light'|'ghost';
  size?: 'sm'|'md'|'lg';
  /** Adds circular arrow chip on the right; rotates 45° on hover */
  arrow?: boolean;
  disabled?: boolean;
  fullWidth?: boolean;
  type?: 'button'|'submit';
  onClick?: (e: React.MouseEvent) => void;
  style?: React.CSSProperties;
}
export declare function Button(props: ButtonProps): JSX.Element;
