export interface IconButtonProps{
  icon?: import('../core/Icon').IconName;
  variant?: 'accent'|'outline'|'light'|'dark'|'glass';
  /** Diameter in px (default 40) */
  size?: number;
  label?: string;
  disabled?: boolean;
  onClick?: (e: React.MouseEvent) => void;
  style?: React.CSSProperties;
}
export declare function IconButton(props: IconButtonProps): JSX.Element;
