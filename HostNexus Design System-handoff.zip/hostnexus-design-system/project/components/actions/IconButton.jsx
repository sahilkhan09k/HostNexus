import React from 'react';
import { Icon } from '../core/Icon.jsx';
const V={accent:['var(--accent)','var(--white)','transparent'],outline:['transparent','var(--text-strong)','var(--border-default)'],light:['var(--white)','var(--ink-900)','transparent'],dark:['var(--ink-900)','var(--white)','transparent'],glass:['rgba(255,255,255,.18)','var(--white)','rgba(255,255,255,.28)']};
export function IconButton({icon='arrow-up-right',variant='accent',size=40,label,disabled=false,onClick,style}){
  const [bg,fg,bd]=V[variant]||V.accent;const [h,setH]=React.useState(false);
  return <button aria-label={label||icon} disabled={disabled} onClick={onClick} onMouseEnter={()=>setH(true)} onMouseLeave={()=>setH(false)}
    style={{width:size,height:size,borderRadius:'50%',border:`1px solid ${bd}`,background:bg,color:fg,display:'grid',placeItems:'center',padding:0,cursor:disabled?'not-allowed':'pointer',
      opacity:disabled?.4:1,backdropFilter:variant==='glass'?'var(--blur-glass)':undefined,filter:h&&!disabled?'brightness(.93)':'none',transition:'filter var(--dur-fast)',...style}}>
    <Icon name={icon} size={Math.round(size*0.42)}/></button>;
}
