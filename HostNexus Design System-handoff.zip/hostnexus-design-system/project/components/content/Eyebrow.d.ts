export interface EyebrowProps{ children?: React.ReactNode; tone?: 'dark'|'light'; style?: React.CSSProperties; }
export declare function Eyebrow(props: EyebrowProps): JSX.Element;
