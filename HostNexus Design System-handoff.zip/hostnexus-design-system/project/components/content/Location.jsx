import React from 'react';
import { Icon } from '../core/Icon.jsx';
export function Location({children,tone='dark',size=12}){
  return <span style={{display:'inline-flex',alignItems:'center',gap:4,whiteSpace:'nowrap',font:`400 ${size}px var(--font-sans)`,color:tone==='light'?'var(--text-inverse-muted)':'var(--text-muted)'}}><Icon name="map-pin" size={size+1}/>{children}</span>;
}
