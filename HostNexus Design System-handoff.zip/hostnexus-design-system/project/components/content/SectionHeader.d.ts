export interface SectionHeaderProps{
  eyebrow?: React.ReactNode;
  title: React.ReactNode;
  description?: React.ReactNode;
  /** Right-aligned (or centered) action, e.g. <Button variant="outline" arrow> */
  action?: React.ReactNode;
  align?: 'left'|'center';
  tone?: 'dark'|'light';
  style?: React.CSSProperties;
}
export declare function SectionHeader(props: SectionHeaderProps): JSX.Element;
