export interface LocationProps{ children?: React.ReactNode; tone?: 'dark'|'light'; size?: number; }
export declare function Location(props: LocationProps): JSX.Element;
