Single amber star + "(4.9 out of 5)" text; use on cards and testimonials.
```jsx
<Rating value={4.8}/>
<Rating value={5} tone="light"/>
```
