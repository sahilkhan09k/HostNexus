export interface LogoItem{ name: string; /** Partner logo image; falls back to name in type */ src?: string; }
export interface LogoStripProps{ logos: LogoItem[]; marquee?: boolean; height?: number; style?: React.CSSProperties; }
export declare function LogoStrip(props: LogoStripProps): JSX.Element;
