export interface TestimonialProps{
  headline: React.ReactNode;
  body?: React.ReactNode;
  author?: React.ReactNode;
  /** Image URL or node (e.g. an image slot). Grey circle when omitted. */
  avatar?: string|React.ReactNode;
  rating?: number;
  style?: React.CSSProperties;
}
export declare function Testimonial(props: TestimonialProps): JSX.Element;
