Large pull-quote: grey quotation glyph, h3 headline, small body, avatar + rating.
```jsx
<Testimonial headline="Exactly What We Needed — Smooth & Stress-Free!" body="The booking process was incredibly smooth…" author="Sarah Ahmed" rating={5}/>
```
