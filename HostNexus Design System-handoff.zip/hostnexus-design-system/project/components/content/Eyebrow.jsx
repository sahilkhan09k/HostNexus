import React from 'react';
export function Eyebrow({children,tone='dark',style}){
  return <div style={{font:'500 var(--text-sm)/1.2 var(--font-sans)',color:tone==='light'?'var(--text-inverse-muted)':'var(--text-body)',letterSpacing:'-0.005em',...style}}>{children}</div>;
}
