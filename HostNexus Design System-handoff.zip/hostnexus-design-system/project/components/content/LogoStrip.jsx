import React from 'react';
export function LogoStrip({logos=[],marquee=true,height=36,style}){
  const row=logos.map((l,i)=><div key={i} style={{flexShrink:0,height,display:'flex',alignItems:'center',opacity:.6,filter:'grayscale(1)'}}>
    {l.src?<img src={l.src} alt={l.name} style={{height:'100%',width:'auto'}}/>:<span style={{font:'400 20px var(--font-sans)',letterSpacing:'0.04em',color:'var(--ink-600)',whiteSpace:'nowrap'}}>{l.name}</span>}</div>);
  return <div style={{overflow:'hidden',maskImage:'linear-gradient(90deg,transparent,#000 10%,#000 90%,transparent)',WebkitMaskImage:'linear-gradient(90deg,transparent,#000 10%,#000 90%,transparent)',...style}}>
    <style>{'@keyframes hnMarquee{from{transform:translateX(0)}to{transform:translateX(-50%)}}'}</style>
    <div style={{display:'flex',gap:64,width:'max-content',animation:marquee?'hnMarquee 40s linear infinite':'none'}}>{row}{marquee&&row}</div>
  </div>;
}
