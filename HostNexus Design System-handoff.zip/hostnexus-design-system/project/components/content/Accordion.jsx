import React from 'react';
import { Icon } from '../core/Icon.jsx';
export function Accordion({items=[],defaultOpen=0,style}){
  const [open,setOpen]=React.useState(defaultOpen);
  return <div style={{display:'flex',flexDirection:'column',...style}}>
    {items.map((it,i)=>{const o=open===i;return <div key={i} style={{borderBottom:'1px solid var(--border-subtle)'}}>
      <button onClick={()=>setOpen(o?-1:i)} style={{width:'100%',display:'flex',alignItems:'center',justifyContent:'space-between',gap:16,padding:'20px 8px',background:'none',border:0,cursor:'pointer',textAlign:'left',
        font:`${o?500:400} 15px/1.3 var(--font-sans)`,color:o?'var(--text-strong)':'var(--text-body)'}}>
        <span style={{flex:1,minWidth:0}}>{it.q}</span><Icon name={o?'chevron-up':'chevron-down'} size={16}/></button>
      <div style={{display:'grid',gridTemplateRows:o?'1fr':'0fr',transition:'grid-template-rows var(--dur-base) var(--ease-out)'}}><div style={{overflow:'hidden'}}>
        <p style={{margin:0,padding:'0 40px 20px 8px',font:'400 13px/1.55 var(--font-sans)',color:'var(--text-muted)'}}>{it.a}</p></div></div>
    </div>})}
  </div>;
}
