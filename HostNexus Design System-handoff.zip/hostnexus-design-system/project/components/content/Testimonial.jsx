import React from 'react';
import { Rating } from './Rating.jsx';
export function Testimonial({headline,body,author,avatar,rating=5,style}){
  return <div style={{display:'grid',gridTemplateColumns:'auto 1fr',gap:32,...style}}>
    <div aria-hidden="true" style={{font:'500 120px/0.8 var(--font-sans)',color:'var(--ink-300)',height:70,letterSpacing:'-0.05em'}}>“</div>
    <div style={{display:'flex',flexDirection:'column',gap:20}}>
      <h3 style={{margin:0,font:'400 var(--text-h3)/1.12 var(--font-sans)',letterSpacing:'var(--tracking-heading)',color:'var(--text-strong)',textWrap:'balance'}}>{headline}</h3>
      <p style={{margin:0,font:'400 14px/1.6 var(--font-sans)',color:'var(--text-body)',maxWidth:520}}>{body}</p>
      <div style={{display:'flex',alignItems:'center',gap:10}}>
        <div style={{width:36,height:36,borderRadius:'50%',overflow:'hidden',background:'var(--ink-200)',flexShrink:0}}>{avatar&&(typeof avatar==='string'?<img src={avatar} alt="" style={{width:'100%',height:'100%',objectFit:'cover'}}/>:avatar)}</div>
        <div style={{display:'flex',flexDirection:'column',gap:2}}><span style={{font:'500 14px var(--font-sans)',color:'var(--text-strong)',whiteSpace:'nowrap'}}>{author}</span><Rating value={rating} size={11}/></div>
      </div>
    </div>
  </div>;
}
