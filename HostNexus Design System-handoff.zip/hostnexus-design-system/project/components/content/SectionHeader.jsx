import React from 'react';
import { Eyebrow } from './Eyebrow.jsx';
export function SectionHeader({eyebrow,title,description,action,align='left',tone='dark',style}){
  const c=align==='center';const fg=tone==='light'?'var(--text-inverse)':'var(--text-strong)';
  return <div style={{display:'flex',flexDirection:c?'column':'row',alignItems:c?'center':'flex-end',justifyContent:'space-between',gap:c?16:32,textAlign:c?'center':'left',width:'100%',boxSizing:'border-box',...style}}>
    <div style={{display:'flex',flexDirection:'column',gap:16,alignItems:c?'center':'flex-start',maxWidth:c?720:640,width:c?'100%':undefined,flex:c?undefined:'1 1 auto',minWidth:0}}>
      {eyebrow&&<Eyebrow tone={tone}>{eyebrow}</Eyebrow>}
      <h2 style={{margin:0,font:'400 var(--text-h2)/1.1 var(--font-sans)',letterSpacing:'var(--tracking-heading)',color:fg,textWrap:'balance'}}>{title}</h2>
      {description&&c&&<p style={{margin:0,font:'400 var(--text-sm)/1.5 var(--font-sans)',color:tone==='light'?'var(--text-inverse-muted)':'var(--text-body)'}}>{description}</p>}
    </div>
    {description&&!c&&<p style={{margin:0,maxWidth:340,font:'400 var(--text-sm)/1.5 var(--font-sans)',color:'var(--text-body)'}}>{description}</p>}
    {action&&<div style={{flexShrink:0}}>{action}</div>}
  </div>;
}
