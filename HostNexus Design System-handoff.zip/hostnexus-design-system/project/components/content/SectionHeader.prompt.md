Section title block: optional eyebrow, h2 title (often two lines), and a right-aligned action or description.
```jsx
<SectionHeader title={<>Our most Amazing<br/>Destination</>} action={<Button variant="outline" arrow size="sm">Explore Now</Button>}/>
<SectionHeader align="center" eyebrow="Explore Hotels" title="Trusted Stays, Seamless Booking" description="Discover top hotels near you."/>
```
