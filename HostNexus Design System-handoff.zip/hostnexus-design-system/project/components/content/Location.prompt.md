Map-pin + place name meta line; use under property names.
```jsx
<Location>Phuket, Thailand</Location>
```
