Greyscale partner-logo rail with edge fade; drifts left as a marquee.
```jsx
<LogoStrip logos={[{name:'Partner A',src:'assets/partners/a.svg'},{name:'Partner B'}]}/>
```
Supply real partner logo files; the name-in-type fallback is a placeholder only.
