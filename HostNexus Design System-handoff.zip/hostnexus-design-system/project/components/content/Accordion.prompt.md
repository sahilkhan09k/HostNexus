Single-open FAQ list with hairline dividers; open item's question goes ink + medium weight.
```jsx
<Accordion items={[{q:'Is it safe to book?',a:'Yes — every payment is encrypted.'}]}/>
```
