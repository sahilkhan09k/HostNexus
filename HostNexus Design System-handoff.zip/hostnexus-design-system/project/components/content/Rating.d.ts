export interface RatingProps{ value?: number; max?: number; /** light = on photos/dark */ tone?: 'dark'|'light'; size?: number; }
export declare function Rating(props: RatingProps): JSX.Element;
