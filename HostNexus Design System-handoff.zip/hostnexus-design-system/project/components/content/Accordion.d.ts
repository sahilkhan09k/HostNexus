export interface AccordionItem{ q: React.ReactNode; a: React.ReactNode; }
/**
 * FAQ accordion — hairline dividers, chevron, single item open.
 * @startingPoint section="Content" subtitle="FAQ accordion" viewport="700x380"
 */
export interface AccordionProps{ items: AccordionItem[]; /** index open initially; -1 for none */ defaultOpen?: number; style?: React.CSSProperties; }
export declare function Accordion(props: AccordionProps): JSX.Element;
