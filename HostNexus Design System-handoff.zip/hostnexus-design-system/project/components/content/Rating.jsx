import React from 'react';
import { Icon } from '../core/Icon.jsx';
export function Rating({value=4.9,max=5,tone='dark',size=12}){
  return <span style={{display:'inline-flex',alignItems:'center',gap:5,whiteSpace:'nowrap',font:`400 ${size}px var(--font-sans)`,color:tone==='light'?'var(--text-inverse-muted)':'var(--text-muted)'}}>
    <Icon name="star" size={size+1} fill="var(--star)" color="var(--star)" strokeWidth={1}/>({value} out of {max})</span>;
}
