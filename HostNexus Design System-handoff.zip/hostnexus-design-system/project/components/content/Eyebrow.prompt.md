Small sentence-case section label ("Our Story", "Testimonial", "FAQs") that sits above or beside a heading.
```jsx
<Eyebrow>Our Story</Eyebrow>
```
Never uppercase; no dots or lines.
