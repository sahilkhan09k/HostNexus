function Testimonials(){
  const {Eyebrow,CarouselControls,Testimonial}=window.HostNexusDesignSystem_229e3d;const t=window.HN_DATA.testimonials;const [i,setI]=React.useState(0);
  return <section data-screen-label="Testimonials" style={{background:'var(--surface-subtle)',padding:'var(--section-y) 0'}}>
    <Container style={{display:'grid',gridTemplateColumns:'minmax(0,1fr) minmax(0,1.4fr)',gap:64}}>
      <div style={{display:'flex',flexDirection:'column',justifyContent:'space-between',gap:48}}>
        <div style={{display:'flex',flexDirection:'column',gap:16}}><Eyebrow>Testimonial</Eyebrow><p style={{margin:0,maxWidth:440,font:'400 var(--text-body-lg)/1.4 var(--font-sans)',color:'var(--text-body)'}}>Here’s what people have to say about working together. Real moments, real experiences, real feedback.</p></div>
        <CarouselControls onPrev={()=>setI(i-1)} onNext={()=>setI(i+1)} canPrev={i>0} canNext={i<t.length-1}/>
      </div>
      <Testimonial key={i} {...t[i]} avatar={<div style={{position:'relative',width:'100%',height:'100%'}}><image-slot id={'avatar-'+i} shape="circle" placeholder="" style={{position:'absolute',inset:0,width:'100%',height:'100%'}}></image-slot></div>}/>
    </Container>
  </section>;
}
window.Testimonials=Testimonials;
