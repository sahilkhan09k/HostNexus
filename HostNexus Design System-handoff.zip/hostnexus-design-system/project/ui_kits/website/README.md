# HostNexus — Marketing website UI kit
Recreation of the hotel-booking landing page shown in the source video (uploads/*.mp4). Sections top to bottom:
Hero (`Hero.jsx`) · Our Story (`Story.jsx`, scroll ink-fill) · Featured destinations bento (`Destinations.jsx`) · Listings carousel (`Listings.jsx`) · Trust + community rail (`Community.jsx`) · Testimonials slider (`Testimonials.jsx`) · FAQ (`Faq.jsx`) · CTA footer (`Footer.jsx`).

Interactions: hero search filters + scrolls to listings; carousel arrows; testimonial prev/next; FAQ accordion; newsletter submit → confirmation.

All photography is `<image-slot>` — drag HostNexus images onto each slot (they persist). Copy lives in `data.js`.
Source brand in the video was "StayGo"; all copy has been re-pointed to HostNexus. Partner names are placeholders — supply real partner logos.
