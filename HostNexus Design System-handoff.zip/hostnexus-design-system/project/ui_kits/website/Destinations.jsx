function Destinations(){
  const {SectionHeader,Button,DestinationCard}=window.HostNexusDesignSystem_229e3d;const d=window.HN_DATA.destinations;
  return <section data-screen-label="Destinations" style={{background:'var(--surface-muted)',padding:'var(--section-y) 0'}}>
    <Container style={{display:'flex',flexDirection:'column',gap:56}}>
      <SectionHeader title={<>Our most Amazing<br/>Destination</>} action={<Button variant="outline" arrow size="sm">Explore Now</Button>}/>
      <div style={{display:'grid',gridTemplateColumns:'minmax(0,1.85fr) minmax(0,1fr)',gridTemplateRows:'260px 260px',gap:16}}>
        <DestinationCard size="lg" height="100%" style={{gridRow:'1 / 3'}} {...d[0]} media={<Slot id="dest-1" label="Feature destination"/>}/>
        <DestinationCard height="100%" {...d[1]} media={<Slot id="dest-2" label="Destination"/>}/>
        <DestinationCard height="100%" {...d[2]} media={<Slot id="dest-3" label="Destination"/>}/>
      </div>
    </Container>
  </section>;
}
window.Destinations=Destinations;
