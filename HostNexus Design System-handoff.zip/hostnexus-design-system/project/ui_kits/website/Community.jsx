function Community(){
  const {SectionHeader,Button,Icon,LogoStrip,NewsletterCard}=window.HostNexusDesignSystem_229e3d;
  const [done,setDone]=React.useState(false);
  const Ph=({id,w,h,y})=><div style={{position:'relative',width:w,height:h,flexShrink:0,borderRadius:'var(--radius-lg)',overflow:'hidden',transform:`translateY(${y}px)`,background:'var(--ink-100)'}}><Slot id={id} label="Stay"/></div>;
  return <section data-screen-label="Community" style={{background:'var(--surface-page)',padding:'var(--section-y) 0',overflow:'hidden'}}>
    <Container style={{display:'flex',flexDirection:'column',alignItems:'center',gap:28}}>
      <SectionHeader align="center" eyebrow="Explore Hotels" title={<>Trusted Stays, Seamless<br/>Booking Explore Now!</>} description="Discover top hotels near you with just a tap—effortless booking, ultimate comfort."/>
      <div style={{display:'flex',flexDirection:'column',alignItems:'center',gap:12}}><Button arrow>Get Started</Button>
        <span style={{display:'flex',alignItems:'center',gap:6,whiteSpace:'nowrap',font:'400 12px var(--font-sans)',color:'var(--text-muted)'}}><Icon name="shield-check" size={14}/>Pause or cancel service anytime</span></div>
    </Container>
    <LogoStrip logos={window.HN_DATA.partners} style={{margin:'48px 0 56px'}}/>
    <div style={{display:'flex',justifyContent:'center',alignItems:'center',gap:40}}>
      <Ph id="rail-1" w={200} h={220} y={-20}/><Ph id="rail-2" w={260} h={250} y={10}/>
      {done?<div style={{width:400,flexShrink:0,background:'var(--surface-card-dark)',borderRadius:'var(--radius-lg)',padding:32,boxSizing:'border-box',textAlign:'center',color:'#fff',font:'400 18px/1.5 var(--font-sans)'}}>Welcome aboard. Your first stay picks arrive this week.</div>
        :<NewsletterCard width={400} style={{flexShrink:0}} placeholder="support@hostnexus.com" onSubmit={()=>setDone(true)}/>}
      <Ph id="rail-3" w={260} h={250} y={40}/><Ph id="rail-4" w={200} h={220} y={-10}/>
    </div>
  </section>;
}
window.Community=Community;
