function Faq(){
  const {Eyebrow,Accordion}=window.HostNexusDesignSystem_229e3d;
  return <section data-screen-label="FAQ" style={{background:'var(--surface-page)',padding:'var(--section-y) 0'}}>
    <Container style={{display:'flex',flexDirection:'column',gap:48}}>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-end',gap:32,flexWrap:'wrap'}}>
        <div style={{display:'flex',flexDirection:'column',gap:16}}><Eyebrow>FAQs</Eyebrow><h2 style={{margin:0,font:'400 var(--text-h2)/1.1 var(--font-sans)',letterSpacing:'var(--tracking-heading)'}}>Got Questions?<br/>We’re Here to Help.</h2></div>
        <p style={{margin:0,maxWidth:360,font:'400 14px/1.55 var(--font-sans)',color:'var(--text-body)'}}>Find quick answers to common questions about booking, cancellations, payments, and more — so you can travel with confidence.</p>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'minmax(0,1fr) minmax(0,1fr)',gap:48,alignItems:'start'}}>
        <Accordion items={window.HN_DATA.faqs}/>
        <div style={{position:'relative',height:480,borderRadius:'var(--radius-md)',overflow:'hidden',background:'var(--ink-100)'}}><Slot id="faq-photo" label="Lifestyle photo"/></div>
      </div>
    </Container>
  </section>;
}
window.Faq=Faq;
