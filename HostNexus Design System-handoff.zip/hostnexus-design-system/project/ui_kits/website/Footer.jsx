function Footer(){
  const {Button}=window.HostNexusDesignSystem_229e3d;const link={font:'400 13px var(--font-sans)',color:'rgba(255,255,255,.85)',textDecoration:'none',whiteSpace:'nowrap'};
  return <footer data-screen-label="Footer" style={{position:'relative',background:'var(--ink-950)',color:'#fff',overflow:'hidden'}}>
    <Slot id="footer-bg" label="Footer photo — cabin in forest at night"/>
    <div style={{position:'absolute',inset:0,background:'linear-gradient(180deg,rgba(11,13,17,.7),rgba(11,13,17,.4) 50%,rgba(11,13,17,.8))',pointerEvents:'none'}}></div>
    <Container style={{position:'relative',pointerEvents:'none',paddingTop:112,paddingBottom:32,display:'flex',flexDirection:'column',gap:64}}>
      <div style={{textAlign:'center',display:'flex',flexDirection:'column',alignItems:'center',gap:20}}>
        <h2 style={{margin:0,font:'400 var(--text-display-l)/1.05 var(--font-sans)',letterSpacing:'var(--tracking-display)'}}>Discover Places You’ll<br/>Never Want to Leave</h2>
        <p style={{margin:0,maxWidth:560,font:'400 14px/1.55 var(--font-sans)',color:'var(--text-inverse-muted)'}}>Your next great stay is waiting. Explore a wide range of handpicked hotels and cozy stays, all tailored to make your journey smooth and memorable. Booking has never been this easy.</p>
        <div style={{pointerEvents:'auto',marginTop:8}}><Button size="lg">Plan Your Stay</Button></div>
      </div>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-end',gap:24,pointerEvents:'auto',marginTop:80}}>
        <div style={{font:'400 13px/1.5 var(--font-sans)'}}>HostNexus HQ<br/>45 Greenview Avenue,<br/>New York, NY 10001, USA<br/>Email: support@hostnexus.com<br/>Phone: +1 (212) 555-0134</div>
        <div style={{display:'flex',gap:40}}>{['Facebook','Instagram','Youtube','Twitter','LinkedIn'].map(s=><a key={s} href="#" style={link}>{s}</a>)}</div>
      </div>
      <div style={{font:'500 clamp(96px,17.5vw,236px)/0.8 var(--font-sans)',letterSpacing:'-0.055em',textAlign:'center',whiteSpace:'nowrap',margin:'-24px 0 0'}}>HostNexus</div>
      <div style={{display:'flex',justifyContent:'space-between',gap:24,pointerEvents:'auto'}}>
        <span style={link}>©2026 HostNexus. All Rights Reserved</span>
        <div style={{display:'flex',gap:40}}>{['Privacy Policy','Terms of Use','Legal Disclaimer','Cookie Policy'].map(s=><a key={s} href="#" style={link}>{s}</a>)}</div>
      </div>
    </Container>
  </footer>;
}
window.Footer=Footer;
