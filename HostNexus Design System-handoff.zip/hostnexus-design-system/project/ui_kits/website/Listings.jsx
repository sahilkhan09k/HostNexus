function Listings({query,onClear,sectionRef}){
  const {SectionHeader,CarouselControls,ListingCard,Button}=window.HostNexusDesignSystem_229e3d;
  const all=window.HN_DATA.listings;const q=(query||'').toLowerCase();
  const items=q?all.filter(l=>(l.title+' '+l.location).toLowerCase().includes(q)):all;
  const rail=React.useRef();const [pos,setPos]=React.useState(0);
  const W=276;const go=dir=>{const n=Math.max(0,Math.min(items.length-1,pos+dir));setPos(n);rail.current.scrollTo({left:n*W,behavior:'smooth'})};
  React.useEffect(()=>{setPos(0);rail.current&&rail.current.scrollTo({left:0})},[query]);
  return <section data-screen-label="Listings" ref={sectionRef} style={{background:'var(--surface-page)',padding:'var(--section-y) 0'}}>
    <Container style={{display:'flex',flexDirection:'column',gap:48}}>
      <SectionHeader eyebrow={query?<span>Results for “{query}” · <a href="#" onClick={e=>{e.preventDefault();onClear()}} style={{color:'var(--accent)'}}>Clear</a></span>:null} title={<>Discover Your<br/>Ideal Destination</>} action={<CarouselControls onPrev={()=>go(-1)} onNext={()=>go(1)} canPrev={pos>0} canNext={pos<items.length-1}/>}/>
      <div ref={rail} style={{display:'flex',gap:16,overflowX:'hidden',marginRight:'calc(-1 * var(--gutter))'}}>
        {items.map(l=><ListingCard key={l.id} width={260} style={{flexShrink:0}} imageHeight={240} {...l} media={<Slot id={'listing-'+l.id} label="Property photo"/>}/>)}
        {!items.length&&<div style={{padding:'40px 0',font:'400 16px var(--font-sans)',color:'var(--text-muted)',display:'flex',gap:16,alignItems:'center'}}>No stays match “{query}”. <Button variant="outline" size="sm" onClick={onClear}>Show all</Button></div>}
      </div>
    </Container>
  </section>;
}
window.Listings=Listings;
