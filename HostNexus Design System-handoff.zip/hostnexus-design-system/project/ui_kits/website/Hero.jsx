function Hero({onSearch}){
  const {NavBar,SearchBar}=window.HostNexusDesignSystem_229e3d;const y=useScrollY();const [loaded,setLoaded]=React.useState(false);React.useEffect(()=>{requestAnimationFrame(()=>setLoaded(true))},[]);
  return <section data-screen-label="Hero" style={{position:'relative',height:760,background:'var(--night-900)',overflow:'hidden',color:'#fff'}}>
    <div style={{position:'absolute',inset:0,transform:`translateY(${y*0.25}px) scale(${loaded?1:1.08})`,transition:'transform 1600ms var(--ease-out)'}}><Slot id="hero-bg" label="Hero photo — architecture at blue hour"/></div>
    <div style={{position:'absolute',inset:0,background:'var(--overlay-hero)',pointerEvents:'none'}}></div>
    <div style={{position:'absolute',left:0,right:0,top:84,textAlign:'center',font:'500 var(--text-wordmark)/0.9 var(--font-sans)',letterSpacing:'-0.05em',color:'rgba(255,255,255,.22)',whiteSpace:'nowrap',pointerEvents:'none',transform:`translateY(${y*0.45}px)`,opacity:Math.max(0,1-y/500)}}>HostNexus</div>
    <Container reveal={false} style={{position:'relative',height:'100%',display:'flex',flexDirection:'column',justifyContent:'space-between',pointerEvents:'none'}}>
      <div style={{pointerEvents:'auto'}}><NavBar active="Explore Hotels"/></div>
      <div style={{display:'flex',alignItems:'flex-end',justifyContent:'space-between',gap:32,paddingBottom:56,flexWrap:'wrap'}}>
        <h1 style={{...revealStyle(loaded,200),margin:0,font:'400 var(--text-display-xl)/1.05 var(--font-sans)',letterSpacing:'var(--tracking-display)'}}>Find Your Perfect Stay<br/>at the Best Price</h1>
        <div style={{pointerEvents:'auto',paddingBottom:12}}><SearchBar width={340} onSubmit={onSearch}/></div>
      </div>
    </Container>
  </section>;
}
window.Hero=Hero;
