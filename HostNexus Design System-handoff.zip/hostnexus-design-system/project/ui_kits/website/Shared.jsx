const Slot=({id,label})=><image-slot id={id} shape="rect" placeholder={label||'Drop image'} style={{position:'absolute',inset:0,width:'100%',height:'100%'}}></image-slot>;
const reduced=()=>window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
function useReveal(threshold=0.15){
  const ref=React.useRef();const [on,setOn]=React.useState(reduced());
  React.useEffect(()=>{if(on||!ref.current)return;const io=new IntersectionObserver(([e])=>{if(e.isIntersecting){setOn(true);io.disconnect()}},{threshold});io.observe(ref.current);return()=>io.disconnect()},[]);
  return [ref,on];
}
const revealStyle=(on,delay=0)=>({opacity:on?1:0,filter:on?'blur(0)':'blur(12px)',transform:on?'none':'translateY(24px)',transition:`opacity var(--dur-reveal) var(--ease-out) ${delay}ms,filter var(--dur-reveal) var(--ease-out) ${delay}ms,transform var(--dur-reveal) var(--ease-out) ${delay}ms`});
const Container=({children,style,reveal=true})=>{const [ref,on]=useReveal();return <div ref={ref} style={{maxWidth:'var(--container-max)',margin:'0 auto',padding:'0 var(--gutter)',boxSizing:'border-box',...(reveal?revealStyle(on):{}),...style}}>{children}</div>};
function useScrollY(){const [y,setY]=React.useState(0);React.useEffect(()=>{if(reduced())return;let r;const on=()=>{cancelAnimationFrame(r);r=requestAnimationFrame(()=>setY(window.scrollY))};window.addEventListener('scroll',on,{passive:true});return()=>window.removeEventListener('scroll',on)},[]);return y;}
Object.assign(window,{Slot,Container,useReveal,revealStyle,useScrollY});
