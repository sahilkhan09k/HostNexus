function Story(){
  const {Eyebrow,Button}=window.HostNexusDesignSystem_229e3d;
  const ref=React.useRef();const [p,setP]=React.useState(0);
  React.useEffect(()=>{const on=()=>{const r=ref.current.getBoundingClientRect();const vh=window.innerHeight;setP(Math.max(0,Math.min(1,(vh*0.9-r.top)/(vh*0.6))))};on();window.addEventListener('scroll',on,{passive:true});return()=>window.removeEventListener('scroll',on)},[]);
  const words='From city escapes to beachside retreats, we connect you with hotels that fit your lifestyle wherever the journey takes you.'.split(' ');
  const lit=Math.round(p*words.length);
  return <section data-screen-label="Our Story" ref={ref} style={{background:'var(--surface-page)',padding:'var(--section-y) 0'}}>
    <Container style={{display:'grid',gridTemplateColumns:'minmax(0,1fr) minmax(0,1.6fr)',gap:64}}>
      <div style={{display:'flex',flexDirection:'column',justifyContent:'space-between',gap:48}}>
        <Eyebrow>Our Story</Eyebrow>
        <p style={{margin:0,maxWidth:340,font:'400 14px/1.6 var(--font-sans)',color:'var(--text-body)'}}>Trusted by over <b style={{color:'var(--text-strong)',fontWeight:600}}>10 million travelers</b> worldwide, we’re proud to deliver top-rated stays with an average <b style={{color:'var(--text-strong)',fontWeight:600}}>rating of 4.8★</b>. Your comfort and satisfaction are always our top priority.</p>
      </div>
      <div style={{display:'flex',flexDirection:'column',gap:40,alignItems:'flex-start'}}>
        <p style={{margin:0,font:'400 var(--text-h3)/1.18 var(--font-sans)',letterSpacing:'var(--tracking-heading)'}}>{words.map((w,i)=><span key={i} style={{color:i<lit?'var(--text-strong)':'var(--ink-400)',transition:'color var(--dur-base)'}}>{w} </span>)}</p>
        <Button variant="outline" arrow>Learn More</Button>
      </div>
    </Container>
  </section>;
}
window.Story=Story;
